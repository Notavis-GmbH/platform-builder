#include "vc_mipi_modules.h"
#include <linux/v4l2-mediabus.h>
int debug = 3;

#define INIT_MESSAGE(camera) \
        struct device *dev = &ctrl->client_mod->dev; \
        vc_notice(dev, "%s(): Initialising module control for %s\n", __FUNCTION__, camera);

#define AGAIN_LIN(_max, _max_mdB) \
        ctrl->again = (vc_gain) { .max = _max, .max_mdB = _max_mdB, \
        .type = GAIN_LINEAR};

#define AGAIN_LOG(_max, _max_mdB, _c0, _c1) \
        ctrl->again = (vc_gain) { .max = _max, .max_mdB = _max_mdB, \
        .type = GAIN_LOGARITHMIC, .c0 = _c0, .c1 = _c1 };

#define AGAIN_REC(_max, _max_mdB, _c0, _c1) \
        ctrl->again = (vc_gain) { .max = _max, .max_mdB = _max_mdB, \
        .type = GAIN_RECIPROCAL, .c0 = _c0, .c1 = _c1 };

#define AGAIN_FRA(_max, _max_mdB) \
        ctrl->again = (vc_gain) { .max = _max, .max_mdB = _max_mdB, \
        .type = GAIN_FRACTIONAL};

#define DGAIN(_max, _max_mdB) \
        ctrl->dgain = (vc_gain) { .max = _max, .max_mdB = _max_mdB };

#define FRAME(_left, _top, _width, _height) \
        ctrl->frame = (vc_frame) { .left = _left, .top = _top, .width = _width, .height = _height };

#define MODE(index, lanes, format, binning, _hmax, vmax_min, vmax_max, vmax_def, \
        blacklevel_max, blacklevel_def, _retrigger_min) \
        ctrl->mode[index] = (vc_mode) { lanes, format, binning, \
                .hmax = {.min = _hmax, .max = _hmax, .def = _hmax},  \
                .vmax = {.min = vmax_min, .max = vmax_max, .def = vmax_def}, \
                .blacklevel = {.min = 0, .max = blacklevel_max,  .def = blacklevel_def }, \
                .retrigger_min = _retrigger_min };

#define MODE_HMAX(index, lanes, format, binning, hmax_min, hmax_max, hmax_def, vmax_min, vmax_max, vmax_def, \
        blacklevel_max, blacklevel_def, _retrigger_min) \
        ctrl->mode[index] = (vc_mode) { lanes, format, binning, \
                .hmax = {.min = hmax_min, .max = hmax_max, .def = hmax_def},  \
                .vmax = {.min = vmax_min, .max = vmax_max, .def = vmax_def}, \
                .blacklevel = {.min = 0, .max = blacklevel_max,  .def = blacklevel_def }, \
                .retrigger_min = _retrigger_min };

#define VMAX_MARGIN(index, scale, margin, floor) \
        ctrl->mode[index].vmax_row_scale  = scale; \
        ctrl->mode[index].vmax_row_margin = margin; \
        ctrl->mode[index].vmax_row_floor  = floor;

#define BINNING_MODE_REGS(_mode, ...) \
        if (MAX_VC_MODES > _mode) { \
                do { \
                        const struct vc_reg _binning_mode_regs [] = { __VA_ARGS__ }; \
                        int vrs = 0; \
                        vrs = sizeof(_binning_mode_regs) / sizeof(vc_reg); \
                                if (MAX_BINNING_MODE_REGS > vrs) { \
                                        memcpy(&ctrl->mode[_mode].binning_mode_regs, _binning_mode_regs, sizeof(_binning_mode_regs)); \
                                } \
                } while (0); \
        }

// Like BINNING_MODE_REGS, but written unconditionally whenever this mode is
// selected (see vc_mode.extra_regs / vc_sen_write_extra_mode_regs()).
#define EXTRA_MODE_REGS(_mode, ...) \
        if (MAX_VC_MODES > _mode) { \
                do { \
                        const struct vc_reg _extra_mode_regs [] = { __VA_ARGS__ }; \
                        int ers = 0; \
                        ers = sizeof(_extra_mode_regs) / sizeof(vc_reg); \
                                if (MAX_EXTRA_MODE_REGS > ers) { \
                                        memcpy(&ctrl->mode[_mode].extra_regs, _extra_mode_regs, sizeof(_extra_mode_regs)); \
                                } \
                } while (0); \
        }


int vc_mod_is_color_sensor(struct vc_desc *desc)
{
        if (desc->sen_type[0] != 0) {
                __u32 len = strnlen(desc->sen_type, 16);
                if (len > 0 && len < 17) {
                        return *(desc->sen_type + len - 1) == 'C';
                }
        }
        return 0;
}
EXPORT_SYMBOL(vc_mod_is_color_sensor);

static void vc_init_ctrl(struct vc_ctrl *ctrl, struct vc_desc* desc)
{
        ctrl->exposure                  = (vc_control) { .min =   1, .max = 100000000, .def =  10000 };
        ctrl->framerate                 = (vc_control) { .min =   0, .max =   1000000, .def =      0 };
        // Default: no margin (SHS == VMAX allowed), preserving every existing
        // sensor's prior behaviour -- see the field comment in vc_mipi_core.h.
        ctrl->vmax_exposure_margin      = 0;
        // Default: no vertical crop alignment constraint -- see the field
        // comment in vc_mipi_core.h. AR2020 sets 2.
        ctrl->crop_top_step             = 1;

        ctrl->csr.sen.mode              = (vc_csr2) { .l = desc->csr_mode, .m = 0x0000 };

        ctrl->csr.sen.mode_standby      = 0x00; 
        ctrl->csr.sen.mode_operating    = 0x01;
        
        ctrl->csr.sen.shs.l             = desc->csr_exposure_l;
        ctrl->csr.sen.shs.m             = desc->csr_exposure_m;
        ctrl->csr.sen.shs.h             = desc->csr_exposure_h;
        ctrl->csr.sen.shs.u             = 0;
        
        ctrl->csr.sen.again.l            = desc->csr_gain_l;
        ctrl->csr.sen.again.m            = desc->csr_gain_h;

        ctrl->csr.sen.h_start.l         = desc->csr_h_start_l;
        ctrl->csr.sen.h_start.m         = desc->csr_h_start_h;
        ctrl->csr.sen.v_start.l         = desc->csr_v_start_l;
        ctrl->csr.sen.v_start.m         = desc->csr_v_start_h;
        ctrl->csr.sen.h_end.l           = desc->csr_h_end_l;
        ctrl->csr.sen.h_end.m           = desc->csr_h_end_h;
        ctrl->csr.sen.v_end.l           = desc->csr_v_end_l;
        ctrl->csr.sen.v_end.m           = desc->csr_v_end_h;
        ctrl->csr.sen.o_width.l         = desc->csr_o_width_l;
        ctrl->csr.sen.o_width.m         = desc->csr_o_width_h;
        ctrl->csr.sen.o_height.l        = desc->csr_o_height_l;
        ctrl->csr.sen.o_height.m        = desc->csr_o_height_h;

        ctrl->frame.left                = 0;
        ctrl->frame.top                 = 0;

        ctrl->clk_ext_trigger           = desc->clk_ext_trigger;
        ctrl->clk_pixel                 = desc->clk_pixel;
}

static void vc_init_ctrl_imx183_base(struct vc_ctrl *ctrl, struct vc_desc* desc)
{
        ctrl->csr.sen.hmax              = (vc_csr4) { .l = 0x7002, .m = 0x7003, .h = 0x0000, .u = 0x0000 };
        ctrl->csr.sen.vmax              = (vc_csr4) { .l = 0x7004, .m = 0x7005, .h = 0x7006, .u = 0x0000 };

        ctrl->flags                     = FLAG_EXPOSURE_SONY;
        ctrl->flags                    |= FLAG_INCREASE_FRAME_RATE;
        ctrl->flags                    |= FLAG_IO_ENABLED;
        ctrl->flags                    |= FLAG_TRIGGER_EXTERNAL | FLAG_TRIGGER_SELF |
                                          FLAG_TRIGGER_SINGLE | FLAG_TRIGGER_SYNC;
}

static void vc_init_ctrl_imx252_base(struct vc_ctrl *ctrl, struct vc_desc* desc)
{
        AGAIN_LIN(480, 48000)
        ctrl->csr.sen.hmax              = (vc_csr4) { .l = 0x0214, .m = 0x0215, .h = 0x0000, .u = 0x0000 };
        ctrl->csr.sen.vmax              = (vc_csr4) { .l = 0x0210, .m = 0x0211, .h = 0x0212, .u = 0x0000 };
        ctrl->csr.sen.blacklevel        = (vc_csr2) { .l = 0x0454, .m = 0x0455 };

        ctrl->flags                     = FLAG_EXPOSURE_SONY;
        ctrl->flags                    |= FLAG_INCREASE_FRAME_RATE;
        ctrl->flags                    |= FLAG_IO_ENABLED;
        ctrl->flags                    |= FLAG_TRIGGER_EXTERNAL | FLAG_TRIGGER_PULSEWIDTH |
                                          FLAG_TRIGGER_SELF | FLAG_TRIGGER_SINGLE;

        TOUT(ctrl->tout,
             0x0226,                                                          /* toutsel_reg */
             0x0229,                                                          /* trigtoutsel_reg */
             0x026d,                                                          /* pulse1_reg */
             ((vc_csr4){.l = 0x0270, .m = 0x0271, .h = 0x0272, .u = 0x0000}), /* pulse1_up_reg */
             ((vc_csr4){.l = 0x0274, .m = 0x0275, .h = 0x0276, .u = 0x0000}), /* pulse1_dn_reg */
             0x0279,                                                          /* pulse2_reg */
             ((vc_csr4){.l = 0x027c, .m = 0x027d, .h = 0x027e, .u = 0x0000}), /* pulse2_up_reg */
             ((vc_csr4){.l = 0x0280, .m = 0x0281, .h = 0x0282, .u = 0x0000})  /* pulse2_dn_reg */
        );
}

static void vc_init_ctrl_imx290_base(struct vc_ctrl *ctrl, struct vc_desc* desc)
{
        AGAIN_LIN(240, 72000)
        ctrl->csr.sen.hmax              = (vc_csr4) { .l = 0x301C, .m = 0x301D, .h = 0x0000, .u = 0x0000 };
        ctrl->csr.sen.vmax              = (vc_csr4) { .l = 0x3018, .m = 0x3019, .h = 0x301A, .u = 0x0000 };
        ctrl->csr.sen.mode_standby      = 0x01;
        ctrl->csr.sen.mode_operating    = 0x00;
        ctrl->csr.sen.blacklevel        = (vc_csr2) { .l = 0x300a, .m = 0x300b };

        FRAME(0, 0, 1920, 1080)
        
        ctrl->clk_ext_trigger           = 37125000;
        ctrl->clk_pixel                 = 37125000;

        ctrl->flags                     = FLAG_EXPOSURE_SONY;
        ctrl->flags                    |= FLAG_INCREASE_FRAME_RATE;
}

static void vc_init_ctrl_imx296_base(struct vc_ctrl *ctrl, struct vc_desc* desc)
{
        AGAIN_LIN(480, 48000)
        ctrl->csr.sen.hmax              = (vc_csr4) { .l = 0x3014, .m = 0x3015, .h = 0x0000, .u = 0x0000 };
        ctrl->csr.sen.vmax              = (vc_csr4) { .l = 0x3010, .m = 0x3011, .h = 0x3012, .u = 0x0000 };
        ctrl->csr.sen.mode              = (vc_csr2) { .l = 0x3000, .m = 0x300A };
        ctrl->csr.sen.mode_standby      = 0x01;
        ctrl->csr.sen.mode_operating	= 0x00;
        ctrl->csr.sen.blacklevel        = (vc_csr2) { .l = 0x3254, .m = 0x3255 };

        TOUT(ctrl->tout,
                0x3026,                                                          /* toutsel_reg */
                0x3029,                                                          /* trigtoutsel_reg */
                0x306d,                                                          /* pulse1_reg */
                ((vc_csr4){.l = 0x3070, .m = 0x3071, .h = 0x3072, .u = 0x0000}), /* pulse1_up_reg */
                ((vc_csr4){.l = 0x3074, .m = 0x3075, .h = 0x3076, .u = 0x0000}), /* pulse1_dn_reg */
                0x3079,                                                          /* pulse2_reg */
                ((vc_csr4){.l = 0x307c, .m = 0x307d, .h = 0x307e, .u = 0x0000}), /* pulse2_up_reg */
                ((vc_csr4){.l = 0x3080, .m = 0x3081, .h = 0x3082, .u = 0x0000})  /* pulse2_dn_reg */
           );

        ctrl->flags                     = FLAG_EXPOSURE_SONY;
        ctrl->flags                    |= FLAG_INCREASE_FRAME_RATE;
        ctrl->flags                    |= FLAG_IO_ENABLED;
        ctrl->flags                    |= FLAG_TRIGGER_EXTERNAL | FLAG_TRIGGER_PULSEWIDTH | FLAG_TRIGGER_SELF_V2;
}

// ------------------------------------------------------------------------------------------------
//  Settings for IMX178/IMX178C  (Rev.02)
//  6.44 MegaPixel Starvis

static void vc_init_ctrl_imx178(struct vc_ctrl *ctrl, struct vc_desc* desc)
{
        INIT_MESSAGE("IMX178")

        vc_init_ctrl_imx183_base(ctrl, desc);

        AGAIN_LIN(480, 48000)

        ctrl->csr.sen.blacklevel        = (vc_csr2) { .l = 0x3015, .m = 0x3016 };

        FRAME(0, 0, 3072, 2048)
        //                              binning  hmax  hmax    hmax  vmax vmax      vmax  blkl  blkl  retrigger
        //                                       min    max     def  min  max        def   max   def
        MODE_HMAX( 0, 2, FORMAT_RAW08, 0,        680, 0xffff,  680,    9,  0x1ffff,  2126,  255,   50,   2698560)
        MODE_HMAX( 1, 2, FORMAT_RAW10, 0,        840, 0xffff,  840,    9,  0x1ffff,  2126, 1023,   50,   2698560)
        MODE_HMAX( 2, 2, FORMAT_RAW12, 0,        984, 0xffff,  984,    9,  0x1ffff,  2126, 1023,  200,   2698560)
        MODE_HMAX( 3, 2, FORMAT_RAW14, 0,       1156, 0xffff, 1156,    9,  0x1ffff,  2126, 4095,  800,   2698560)
        MODE_HMAX( 4, 4, FORMAT_RAW08, 0,        600, 0xffff,  600,    9,  0x1ffff,  2126,  255,   50,   2698560)
        MODE_HMAX( 5, 4, FORMAT_RAW10, 0,        600, 0xffff,  600,    9,  0x1ffff,  2126, 1023,   50,   2698560)
        MODE_HMAX( 6, 4, FORMAT_RAW12, 0,        680, 0xffff,  680,    9,  0x1ffff,  2126, 1023,  200,   2698560)
        MODE_HMAX( 7, 4, FORMAT_RAW14, 0,       1156, 0xffff, 1156,    9,  0x1ffff,  2126, 4095,  800,   2698560)
        VMAX_MARGIN(0, 1, 28, 0)
        VMAX_MARGIN(1, 1, 28, 0)
        VMAX_MARGIN(2, 1, 28, 0)
        VMAX_MARGIN(3, 1, 28, 0)
        VMAX_MARGIN(4, 1, 28, 0)
        VMAX_MARGIN(5, 1, 28, 0)
        VMAX_MARGIN(6, 1, 28, 0)
        VMAX_MARGIN(7, 1, 28, 0)
}

// ------------------------------------------------------------------------------------------------
//  Settings for IMX183/IMX183C (Rev.15)
//  20.2 MegaPixel

static void vc_init_ctrl_imx183(struct vc_ctrl *ctrl, struct vc_desc* desc)
{
        INIT_MESSAGE("IMX183")

        vc_init_ctrl_imx183_base(ctrl, desc);

        AGAIN_LOG(1957, 27000, 2048, 2048)
        
        ctrl->csr.sen.blacklevel        = (vc_csr2) { .l = 0x0045, .m = 0x0000 };

        FRAME(0, 0, 5440, 3648)

        //                              binning  hmax  hmax    hmax  vmax vmax      vmax  blkl  blkl  retrigger
        //                                       min    max     def  min  max        def   max   def
        MODE_HMAX( 0, 2, FORMAT_RAW08, 0,       1440, 0xffff, 1440,    5,  0x1ffff,  3728,  255,   50,   3599997)
        MODE_HMAX( 1, 2, FORMAT_RAW10, 0,       1440, 0xffff, 1440,    5,  0x1ffff,  3728,  255,   50,   3599997)
        MODE_HMAX( 2, 2, FORMAT_RAW12, 0,       1724, 0xffff, 1724,    5,  0x1ffff,  3728,  255,   50,   3599997)
        MODE_HMAX( 3, 4, FORMAT_RAW08, 0,        720, 0xffff,  720,    5,  0x1ffff,  3728,  255,   50,   3599997)
        MODE_HMAX( 4, 4, FORMAT_RAW10, 0,        720, 0xffff,  720,    5,  0x1ffff,  3728,  255,   50,   3599997)
        MODE_HMAX( 5, 4, FORMAT_RAW12, 0,        862, 0xffff,  862,    5,  0x1ffff,  3728,  255,   50,   3599997)
        VMAX_MARGIN(0, 1, 80, 0)
        VMAX_MARGIN(1, 1, 80, 0)
        VMAX_MARGIN(2, 1, 80, 0)
        VMAX_MARGIN(3, 1, 80, 0)
        VMAX_MARGIN(4, 1, 80, 0)
        VMAX_MARGIN(5, 1, 80, 0)
}

// ------------------------------------------------------------------------------------------------
//  Settings for IMX226/IMX226C (Rev.16)
//  12.4 MegaPixel Starvis

static void vc_init_ctrl_imx226(struct vc_ctrl *ctrl, struct vc_desc* desc)
{
        INIT_MESSAGE("IMX226")

        vc_init_ctrl_imx183_base(ctrl, desc);

        AGAIN_LOG(1957, 27000, 2048, 2048)
        
        ctrl->csr.sen.blacklevel        = (vc_csr2) { .l = 0x0045, .m = 0x0000 };

        FRAME(0, 0, 3904, 3000)
        //                              binning  hmax  hmax    hmax  vmax vmax      vmax  blkl  blkl  retrigger
        //                                       min    max     def  min  max        def   max   def
        MODE_HMAX( 0, 2, FORMAT_RAW08, 0,       1072, 0xffff, 1072,    5,  0x1ffff,  3079,  255,   50,   2698560)
        MODE_HMAX( 1, 2, FORMAT_RAW10, 0,       1072, 0xffff, 1072,    5,  0x1ffff,  3079,  255,   50,   2698560)
        MODE_HMAX( 2, 2, FORMAT_RAW12, 0,       1288, 0xffff, 1288,    5,  0x1ffff,  3079,  255,   50,   2698560)
        MODE_HMAX( 3, 4, FORMAT_RAW08, 0,        536, 0xffff,  536,    5,  0x1ffff,  3079,  255,   50,   2698560)
        MODE_HMAX( 4, 4, FORMAT_RAW10, 0,        536, 0xffff,  536,    5,  0x1ffff,  3079,  255,   50,   2698560)
        MODE_HMAX( 5, 4, FORMAT_RAW12, 0,        644, 0xffff,  644,    5,  0x1ffff,  3079,  255,   50,   2698560)
        VMAX_MARGIN(0, 1, 79, 0)
        VMAX_MARGIN(1, 1, 79, 0)
        VMAX_MARGIN(2, 1, 79, 0)
        VMAX_MARGIN(3, 1, 79, 0)
        VMAX_MARGIN(4, 1, 79, 0)
        VMAX_MARGIN(5, 1, 79, 0)

        ctrl->clk_pixel                 = 72000000;

        ctrl->flags                    |= FLAG_FORMAT_GBRG;
        ctrl->flags                    |= FLAG_RESET_ALWAYS;
        ctrl->flags                    |= FLAG_TRIGGER_STREAM_EDGE | FLAG_TRIGGER_STREAM_LEVEL;
}

// ------------------------------------------------------------------------------------------------
//  Settings for IMX250/IMX250C (Rev.09)
//  5.01 MegaPixel Pregius

static void vc_init_ctrl_imx250(struct vc_ctrl *ctrl, struct vc_desc* desc)
{
        INIT_MESSAGE("IMX250")

        vc_init_ctrl_imx252_base(ctrl, desc);

        FRAME(0, 0, 2432, 2048)
        //                              binning  hmax  hmax    hmax  vmax vmax      vmax  blkl  blkl  retrigger
        //                                       min    max     def  min  max        def   max   def
        MODE_HMAX( 0, 2, FORMAT_RAW08, 0,        540, 0xffff,  540,   10,  0xfffff,  2094,  255,   15,   1580040)
        MODE_HMAX( 1, 2, FORMAT_RAW10, 0,        660, 0xffff,  660,   10,  0xfffff,  2094, 1023,   60,   1580040)
        MODE_HMAX( 2, 2, FORMAT_RAW12, 0,        780, 0xffff,  780,   10,  0xfffff,  2094, 4095,  240,   1580040)
        MODE_HMAX( 3, 4, FORMAT_RAW08, 0,        350, 0xffff,  350,   10,  0xfffff,  2094,  255,   15,   1580040)
        MODE_HMAX( 4, 4, FORMAT_RAW10, 0,        430, 0xffff,  430,   10,  0xfffff,  2094, 1023,   60,   1580040)
        MODE_HMAX( 5, 4, FORMAT_RAW12, 0,        510, 0xffff,  510,   10,  0xfffff,  2094, 4095,  240,   1580040)
        VMAX_MARGIN(0, 1, 38, 0)
        VMAX_MARGIN(1, 1, 38, 0)
        VMAX_MARGIN(2, 1, 38, 0)
        VMAX_MARGIN(3, 1, 38, 0)
        VMAX_MARGIN(4, 1, 38, 0)
        VMAX_MARGIN(5, 1, 38, 0)
}

// ------------------------------------------------------------------------------------------------
//  Settings for IMX252/IMX252C (Rev.12)
//  3.15 MegaPixel Pregius

static void vc_init_ctrl_imx252(struct vc_ctrl *ctrl, struct vc_desc* desc)
{
        INIT_MESSAGE("IMX252")

        vc_init_ctrl_imx252_base(ctrl, desc);

        FRAME(0, 0, 2048, 1536)
        //                              binning  hmax  hmax    hmax  vmax vmax      vmax  blkl  blkl  retrigger
        //                                       min    max     def  min  max        def   max   def
        MODE_HMAX( 0, 2, FORMAT_RAW08, 0,        460, 0xffff,  460,   10,  0xfffff,  1582,  255,   15,   1063754)
        MODE_HMAX( 1, 2, FORMAT_RAW10, 0,        560, 0xffff,  560,   10,  0xfffff,  1582, 1023,   60,   1063754)
        MODE_HMAX( 2, 2, FORMAT_RAW12, 0,        672, 0xffff,  672,   10,  0xfffff,  1582, 4095,  240,   1063754)
        MODE_HMAX( 3, 4, FORMAT_RAW08, 0,        310, 0xffff,  310,   10,  0xfffff,  1582,  255,   15,   1063754)
        MODE_HMAX( 4, 4, FORMAT_RAW10, 0,        380, 0xffff,  380,   10,  0xfffff,  1582, 1023,   60,   1063754)
        MODE_HMAX( 5, 4, FORMAT_RAW12, 0,        444, 0xffff,  444,   10,  0xfffff,  1582, 4095,  240,   1063754)
        VMAX_MARGIN(0, 1, 38, 0)
        VMAX_MARGIN(1, 1, 38, 0)
        VMAX_MARGIN(2, 1, 38, 0)
        VMAX_MARGIN(3, 1, 38, 0)
        VMAX_MARGIN(4, 1, 38, 0)
        VMAX_MARGIN(5, 1, 38, 0)
}

// ------------------------------------------------------------------------------------------------
//  Settings for IMX264/IMX264C (Rev.05)
//  5.1 MegaPixel Pregius

static void vc_init_ctrl_imx264(struct vc_ctrl *ctrl, struct vc_desc* desc)
{
        INIT_MESSAGE("IMX264")

        vc_init_ctrl_imx252_base(ctrl, desc);

        FRAME(0, 0, 2432, 2048)
        // All read out      binning    hmax  vmax      vmax   vmax  blkl  blkl  retrigger
        //                      mode           min       max    def   max   def
        MODE( 0, 2, FORMAT_RAW08, 0,     996,   10,  0xfffff,  2100,  255,   15,   1580040)
        MODE( 1, 2, FORMAT_RAW10, 0,     996,   10,  0xfffff,  2100, 1023,   60,   1580040)
        MODE( 2, 2, FORMAT_RAW12, 0,     996,   10,  0xfffff,  2100, 4095,  240,   1580040)
}

// ------------------------------------------------------------------------------------------------
//  Settings for IMX265/IMX265C (Rev.05)
//  3.2 MegaPixel Pregius

static void vc_init_ctrl_imx265(struct vc_ctrl *ctrl, struct vc_desc* desc)
{
        INIT_MESSAGE("IMX265")

        vc_init_ctrl_imx252_base(ctrl, desc);

        FRAME(0, 0, 2048, 1536)
        // All read out      binning    hmax  vmax      vmax   vmax  blkl  blkl  retrigger
        //                      mode           min       max    def   max   def
        MODE( 0, 2, FORMAT_RAW08, 0,     846,   10,  0xfffff,  1587,  255,  15,   1580040)
        MODE( 1, 2, FORMAT_RAW10, 0,     846,   10,  0xfffff,  1587, 1023,  60,   1580040)
        MODE( 2, 2, FORMAT_RAW12, 0,     846,   10,  0xfffff,  1587, 4095, 240,   1580040)
}

// ------------------------------------------------------------------------------------------------
//  Settings for IMX273/IMX273C (Rev.16)
//  1.56 MegaPixel Pregius

static void vc_init_ctrl_imx273(struct vc_ctrl *ctrl, struct vc_desc* desc)
{
        INIT_MESSAGE("IMX273")

        vc_init_ctrl_imx252_base(ctrl, desc);

        FRAME(0, 0, 1440, 1080)
        //                              binning  hmax  hmax    hmax  vmax vmax      vmax  blkl  blkl  retrigger
        //                                       min    max     def  min  max        def   max   def
        MODE_HMAX( 0, 2, FORMAT_RAW08, 0,        336, 0xffff,  336,   15,  0xfffff,  1130,  255,   15,    519230)
        MODE_HMAX( 1, 2, FORMAT_RAW10, 0,        420, 0xffff,  420,   15,  0xfffff,  1130, 1023,   60,    519230)
        MODE_HMAX( 2, 2, FORMAT_RAW12, 0,        480, 0xffff,  480,   15,  0xfffff,  1130, 4095,  240,    519230)
        MODE_HMAX( 3, 4, FORMAT_RAW08, 0,        238, 0xffff,  238,   15,  0xfffff,  1130,  255,   15,    519230)
        MODE_HMAX( 4, 4, FORMAT_RAW10, 0,        290, 0xffff,  290,   15,  0xfffff,  1130, 1032,   60,    519230)
        MODE_HMAX( 5, 4, FORMAT_RAW12, 0,        396, 0xffff,  396,   15,  0xfffff,  1130, 4095,  240,    519230)
        VMAX_MARGIN(0, 1, 42, 0)
        VMAX_MARGIN(1, 1, 42, 0)
        VMAX_MARGIN(2, 1, 42, 0)
        VMAX_MARGIN(3, 1, 42, 0)
        VMAX_MARGIN(4, 1, 42, 0)
        VMAX_MARGIN(5, 1, 42, 0)
        // binning
        MODE_HMAX( 6, 2, FORMAT_RAW08, 1,        336, 0xffff,  336,   15,  0xfffff,   586,  255,   15,    519230)
        MODE_HMAX( 7, 2, FORMAT_RAW10, 1,        420, 0xffff,  420,   15,  0xfffff,   586, 1023,   60,    519230)
        MODE_HMAX( 8, 2, FORMAT_RAW12, 1,        480, 0xffff,  480,   15,  0xfffff,   586, 4095,  240,    519230)
        MODE_HMAX( 9, 4, FORMAT_RAW08, 1,        218, 0xffff,  218,   15,  0xfffff,   586,  255,   15,    519230)
        MODE_HMAX(10, 4, FORMAT_RAW10, 1,        250, 0xffff,  250,   15,  0xfffff,   586, 1032,   60,    519230)
        MODE_HMAX(11, 4, FORMAT_RAW12, 1,        396, 0xffff,  396,   15,  0xfffff,   586, 4095,  240,    519230)

        BINNING(ctrl->binnings[0], 0, 0)
        BINNING(ctrl->binnings[1], 2, 2)

        TOUT(ctrl->tout, \
                0x0226,  /* toutsel_reg */ \
                0x0229,  /* trigtoutsel_reg */ \
                0x026d,  /* pulse1_reg */ \
                ((vc_csr4){.l=0x0270, .m=0x0271, .h = 0x0272, .u = 0x0000 }),  /* pulse1_up_reg */ \
                ((vc_csr4){.l=0x0274, .m=0x0275, .h = 0x0276, .u = 0x0000 }),  /* pulse1_dn_reg */ \
                0x0279,  /* pulse2_reg */ \
                ((vc_csr4){.l=0x027c, .m=0x027d, .h = 0x027e, .u = 0x0000 }),  /* pulse2_up_reg */ \
                ((vc_csr4){.l=0x0280, .m=0x0281, .h = 0x0282, .u = 0x0000 })   /* pulse2_dn_reg */ \
           );        

        ctrl->max_binning_modes_used = 1;
        ctrl->flags                    |= FLAG_USE_BINNING_INDEX;
}

// ------------------------------------------------------------------------------------------------
//  Settings for IMX290 (Rev.02)
//  2.0 MegaPixel Starvis

static void vc_init_ctrl_imx290(struct vc_ctrl *ctrl, struct vc_desc* desc)
{
        INIT_MESSAGE("IMX290")

        vc_init_ctrl_imx290_base(ctrl, desc);

        // All read out      binning    hmax  vmax      vmax   vmax  blkl  blkl  retrigger
        //                      mode           min       max    def   max   def
        MODE( 0, 2, FORMAT_RAW10, 0,    1100,    1,  0x3ffff, 0x465,  511,   60,         0)
        MODE( 1, 2, FORMAT_RAW12, 0,    1100,    1,  0x3ffff, 0x465,  511,  240,         0)
        MODE( 2, 4, FORMAT_RAW10, 0,     550,    1,  0x3ffff, 0x465,  511,   60,         0)
        MODE( 3, 4, FORMAT_RAW12, 0,     550,    1,  0x3ffff, 0x465,  511,  240,         0)
        VMAX_MARGIN(0, 1, 19, 0)
        VMAX_MARGIN(1, 1, 19, 0)
        VMAX_MARGIN(2, 1, 19, 0)
        VMAX_MARGIN(3, 1, 19, 0)
}

// ------------------------------------------------------------------------------------------------
//  Settings for IMX296/IMX296C (Rev.43)
//  1.56 MegaPixel Pregius

static void vc_init_ctrl_imx296(struct vc_ctrl *ctrl, struct vc_desc* desc)
{
        INIT_MESSAGE("IMX296")

        vc_init_ctrl_imx296_base(ctrl, desc);

        FRAME(0, 0, 1440, 1080)
        // All read out      binning  hmax    hmax     hmax  vmax      vmax   vmax  blkl  blkl  retrigger
        //                      mode   min      max      def   min       max    def   max   def
        MODE_HMAX( 0, 1, FORMAT_RAW10, 0,   0x44c, 0xffff, 0x44c,    5,  0xfffff, 0x45e, 1023,   60,    883008)
        VMAX_MARGIN(0, 1, 30, 0)
        // binning
         // NOTE: Since the data sheet values of hmax (0x42e) and vmax (0x23e) does not lead
         // to correct exposure time and frame rate, the values are optimized.
        MODE_HMAX( 1, 1, FORMAT_RAW10, 1,   0x44c, 0xffff, 0x44c,    5,  0xfffff, 0x22f, 1023,   60,    883008)

        TOUT(ctrl->tout, \
                0x3026,  /* toutsel_reg */ \
                0x3029,  /* trigtoutsel_reg */ \
                0x306d,  /* pulse1_reg */ \
                ((vc_csr4){.l=0x3070, .m=0x3071, .h = 0x3072, .u = 0x0000 }),  /* pulse1_up_reg */ \
                ((vc_csr4){.l=0x3074, .m=0x3075, .h = 0x3076, .u = 0x0000 }),  /* pulse1_dn_reg */ \
                0x3079,  /* pulse2_reg */ \
                ((vc_csr4){.l=0x307c, .m=0x307d, .h = 0x307e, .u = 0x0000 }),  /* pulse2_up_reg */ \
                ((vc_csr4){.l=0x3080, .m=0x3081, .h = 0x3082, .u = 0x0000 })   /* pulse2_dn_reg */ \
           );  

        BINNING(ctrl->binnings[0], 0, 0)
        BINNING(ctrl->binnings[1], 2, 2)

        
        
        ctrl->max_binning_modes_used = 1;
        ctrl->flags                    |= FLAG_USE_BINNING_INDEX;
        ctrl->flags                    |= FLAG_INCREASE_FRAME_RATE;
}

// ------------------------------------------------------------------------------------------------
//  Settings for IMX297 (Rev.43)
//  0.39 MegaPixel Pregius

static void vc_init_ctrl_imx297(struct vc_ctrl *ctrl, struct vc_desc* desc)
{       
        INIT_MESSAGE("IMX297")

        vc_init_ctrl_imx296_base(ctrl, desc);

        FRAME(0, 0, 720, 540) 
        // All read out      binning  hmax    hmax     hmax  vmax      vmax   vmax  blkl  blkl  retrigger
        //                      mode   min      max      def   min       max    def   max   def
        MODE_HMAX( 0, 1, FORMAT_RAW10, 0,   0x42e, 0xffff, 0x42e,    5,  0xfffff, 0x23e,  511,   60,    883008)
}

// ------------------------------------------------------------------------------------------------
//  Settings for IMX327C (Rev.02)
//  2 MegaPixel Starvis

// NOTES:
// - For vertical flipping VREVERSE 0x3007 = 0x01 has to be set.
// - For horizontal flipping HREVERSE 0x3007 = 0x02 has to be set.
// - For cropping WINMODE 0x3007 = 0x40 has to be set. Unfortunatly cropping mode does not reduce 
//   the image size. The image is always filled up to a size of 1920x1080.
// - To increase the frame rate it is possible to reduce VMAX. In this case the image height is forced
//   to be height = VMAX - 15. This is independend of the cropped image height.
// => Cropping is not properly supported.
// => Frame rate increase by image height reduction could be implemented. 
//    But, it need an own implementation.

static void vc_init_ctrl_imx327(struct vc_ctrl *ctrl, struct vc_desc* desc)
{
        INIT_MESSAGE("IMX327")

        vc_init_ctrl_imx290_base(ctrl, desc);
       
        // All read out      binning    hmax  vmax      vmax   vmax  blkl  blkl  retrigger
        //                      mode           min       max    def   max   def
        MODE( 0, 2, FORMAT_RAW10, 0,    1100,    1,  0x3ffff, 0x465,  511,   60,         0)
        MODE( 1, 2, FORMAT_RAW12, 0,    1100,    1,  0x3ffff, 0x465,  511,  240,         0)
        MODE( 2, 4, FORMAT_RAW10, 0,    1100,    1,  0x3ffff, 0x465,  511,   60,         0)
        MODE( 3, 4, FORMAT_RAW12, 0,    1100,    1,  0x3ffff, 0x465,  511,  240,         0)
        VMAX_MARGIN(0, 1, 19, 0)
        VMAX_MARGIN(1, 1, 19, 0)
        VMAX_MARGIN(2, 1, 19, 0)
        VMAX_MARGIN(3, 1, 19, 0)
}

// ------------------------------------------------------------------------------------------------
//  Settings for IMX335 (Rev.02)
//  5.0 MegaPixel Starvis

static void vc_init_ctrl_imx335(struct vc_ctrl *ctrl, struct vc_desc* desc)
{
        INIT_MESSAGE("IMX335")

        AGAIN_LIN(240, 72000)

        ctrl->csr.sen.blacklevel        = (vc_csr2) { .l = 0x3302, .m = 0x3303 };
        ctrl->csr.sen.hmax              = (vc_csr4) { .l = 0x3034, .m = 0x3035, .h = 0x0000, .u = 0x0000 };
        ctrl->csr.sen.vmax              = (vc_csr4) { .l = 0x3030, .m = 0x3031, .h = 0x3032, .u = 0x0000 };
        ctrl->csr.sen.mode_standby      = 0x01;
        ctrl->csr.sen.mode_operating    = 0x00;

        FRAME(7, 52, 2592, 1944)
        // All read out      binning  hmax    hmax     hmax  vmax      vmax   vmax  blkl  blkl  retrigger
        //                      mode   min      max      def   min       max    def   max   def
        MODE_HMAX( 0, 2, FORMAT_RAW10, 0,   0x226, 0xffff, 0x226,    9,  0xfffff,  4500, 1023,   50,         0)
        MODE_HMAX( 1, 2, FORMAT_RAW12, 0,   0x226, 0xffff, 0x226,    9,  0xfffff,  4500, 1023,   50,         0)
        MODE_HMAX( 2, 4, FORMAT_RAW10, 0,   0x113, 0xffff, 0x113,    9,  0xfffff,  4500, 1023,   50,         0)
        MODE_HMAX( 3, 4, FORMAT_RAW12, 0,   0x113, 0xffff, 0x113,    9,  0xfffff,  4500, 1023,   50,         0)
        VMAX_MARGIN(0, 2, 48, 0)
        VMAX_MARGIN(1, 2, 48, 0)
        VMAX_MARGIN(2, 2, 48, 0)
        VMAX_MARGIN(3, 2, 48, 0)

        ctrl->flags                    |= FLAG_EXPOSURE_SONY;
        ctrl->flags                    |= FLAG_INCREASE_FRAME_RATE;
        ctrl->flags                    |= FLAG_DOUBLE_HEIGHT;
        
        ctrl->flags                    |= FLAG_IO_ENABLED;
}

// ------------------------------------------------------------------------------------------------
//  Settings for IMX392/IMX392C (Rev.08)
//  2.3 MegaPixel Pregius

static void vc_init_ctrl_imx392(struct vc_ctrl *ctrl, struct vc_desc* desc)
{
        INIT_MESSAGE("IMX392")

        vc_init_ctrl_imx252_base(ctrl, desc);

        FRAME(0, 0, 1920, 1200)
        //                              binning  hmax  hmax    hmax  vmax vmax      vmax  blkl  blkl  retrigger
        //                                       min    max     def  min  max        def   max   def
        MODE_HMAX( 0, 2, FORMAT_RAW08, 0,        448, 0xffff,  448,   10,  0xfffff,  1252,  255,   15,   1063754)
        MODE_HMAX( 1, 2, FORMAT_RAW10, 0,        530, 0xffff,  530,   10,  0xfffff,  1252, 1023,   60,   1063754)
        MODE_HMAX( 2, 2, FORMAT_RAW12, 0,        624, 0xffff,  624,   10,  0xfffff,  1252, 4095,  240,   1063754)
        MODE_HMAX( 3, 4, FORMAT_RAW08, 0,        294, 0xffff,  294,   10,  0xfffff,  1252,  255,   15,   1063754)
        MODE_HMAX( 4, 4, FORMAT_RAW10, 0,        355, 0xffff,  355,   10,  0xfffff,  1252, 1023,   60,   1063754)
        MODE_HMAX( 5, 4, FORMAT_RAW12, 0,        441, 0xffff,  441,   10,  0xfffff,  1252, 4095,  240,   1063754)
        VMAX_MARGIN(3, 1, 54, 0)
        VMAX_MARGIN(4, 1, 52, 0)
        VMAX_MARGIN(5, 1, 50, 0)
}

// ------------------------------------------------------------------------------------------------
//  Settings for IMX412C (Rev.05)
//  12.3 MegaPixel Starvis
//  
//  TODO: 
//  - No black level (0x0B04 <= 1 - Black level correction enable)

#define IMX412_BINNING_MODE            0x0900
#define IMX412_BINNING_MODE_DISABLE    0x00
#define IMX412_BINNING_MODE_ENABLE     0x01
#define IMX412_BINNING_TYPE            0x0901
#define IMX412_BINNING_WEIGHTING       0x0902
#define IMX412_BINNING_WEIGHTING_AVG   0x00
#define IMX412_BINNING_WEIGHTING_SUM   0x01
#define IMX412_BINNING_TYPE_EXT_EN     0x3f42
#define IMX412_BINNING_TYPE_H_EXT      0x3f43
#define IMX412_BLACKLEVEL_ENABLE       0x3030

static void vc_init_ctrl_imx412(struct vc_ctrl *ctrl, struct vc_desc* desc)
{
        INIT_MESSAGE("IMX412")
        
        AGAIN_REC(978, 13400, 1024, 1024)
        DGAIN(0x0fff, 12000);

        ctrl->csr.sen.dgain             = (vc_csr2) { .l = 0x020f, .m = 0x020e };
        ctrl->csr.sen.blacklevel        = (vc_csr2) { .l = 0x3033, .m = 0x3032 };
        ctrl->csr.sen.hmax              = (vc_csr4) { .l = 0x0343, .m = 0x0342, .h = 0x0000, .u = 0x0000 };
        ctrl->csr.sen.vmax              = (vc_csr4) { .l = 0x0341, .m = 0x0340, .h = 0x0000, .u = 0x0000 };
        ctrl->csr.sen.shs               = (vc_csr4) { .l = 0x0203, .m = 0x0202, .h = 0x0000, .u = 0x0000 };

        FRAME(0, 0, 4032, 3040)
        // All read out      binning    hmax  vmax      vmax    vmax  blkl  blkl  retrigger
        //                      mode           min       max     def   max   def
        MODE( 0, 2, FORMAT_RAW10, 0,     436,   10,   0xffff, 0x0c14, 1023,   40,         0)
        MODE( 1, 4, FORMAT_RAW10, 0,     218,   10,   0xffff, 0x0c14, 1023,   40,         0)
        VMAX_MARGIN(0, 1, 506, 0)
        VMAX_MARGIN(1, 1, 506, 0)

        MODE( 2, 2, FORMAT_RAW10, 1,     436,   10,   0xffff, 0x0624, 1023,   40,         0)
        MODE( 3, 4, FORMAT_RAW10, 1,     218,   10,   0xffff, 0x0624, 1023,   40,         0)
        MODE( 4, 2, FORMAT_RAW10, 2,     436,   10,   0xffff, 0x0624, 1023,   40,         0)
        MODE( 5, 4, FORMAT_RAW10, 2,     218,   10,   0xffff, 0x0624, 1023,   40,         0)
        MODE( 6, 2, FORMAT_RAW10, 3,     436,   10,   0xffff, 0x0624, 1023,   40,         0)
        MODE( 7, 4, FORMAT_RAW10, 3,     218,   10,   0xffff, 0x0624, 1023,   40,         0)
        MODE( 8, 2, FORMAT_RAW10, 4,     436,   10,   0xffff, 0x0624, 1023,   40,         0)
        MODE( 9, 4, FORMAT_RAW10, 4,     218,   10,   0xffff, 0x0624, 1023,   40,         0)
        MODE(10, 2, FORMAT_RAW10, 5,     436,   10,   0xffff, 0x0624, 1023,   40,         0)
        MODE(11, 4, FORMAT_RAW10, 5,     218,   10,   0xffff, 0x0624, 1023,   40,         0)

        ctrl->clk_ext_trigger           = 37125000;
        ctrl->clk_pixel                 = 37125000;

        BINNING_START(ctrl->binnings[0], 0, 0)
                { IMX412_BINNING_MODE, IMX412_BINNING_MODE_DISABLE },
                { IMX412_BINNING_TYPE, 0x11 },
                { IMX412_BLACKLEVEL_ENABLE, 0x01 }
        BINNING_END(ctrl->binnings[0])
        BINNING_START(ctrl->binnings[1], 1, 2)
                { IMX412_BINNING_MODE, IMX412_BINNING_MODE_ENABLE },
                { IMX412_BINNING_WEIGHTING, IMX412_BINNING_WEIGHTING_SUM },
                { IMX412_BINNING_TYPE, 0x12 },
                { IMX412_BLACKLEVEL_ENABLE, 0x01 }
        BINNING_END(ctrl->binnings[1])
        BINNING_START(ctrl->binnings[2], 2, 2)
                { IMX412_BINNING_MODE, IMX412_BINNING_MODE_ENABLE },
                { IMX412_BINNING_WEIGHTING, IMX412_BINNING_WEIGHTING_SUM },
                { IMX412_BINNING_TYPE, 0x22 },
                { IMX412_BLACKLEVEL_ENABLE, 0x01 }
        BINNING_END(ctrl->binnings[2])
        BINNING_START(ctrl->binnings[3], 4, 2)
                { IMX412_BINNING_MODE, IMX412_BINNING_MODE_ENABLE },
                { IMX412_BINNING_WEIGHTING, IMX412_BINNING_WEIGHTING_SUM },
                { IMX412_BINNING_TYPE, 0x42 },
                { IMX412_BLACKLEVEL_ENABLE, 0x01 }
        BINNING_END(ctrl->binnings[3])
        BINNING_START(ctrl->binnings[4], 8, 2)
                { IMX412_BINNING_MODE, IMX412_BINNING_MODE_ENABLE },
                { IMX412_BINNING_WEIGHTING, IMX412_BINNING_WEIGHTING_SUM },
                { IMX412_BINNING_TYPE, 0x82 },
                { IMX412_BLACKLEVEL_ENABLE, 0x01 }
        BINNING_END(ctrl->binnings[4])
        BINNING_START(ctrl->binnings[5], 16, 2)
                { IMX412_BINNING_MODE, IMX412_BINNING_MODE_ENABLE },
                { IMX412_BINNING_WEIGHTING, IMX412_BINNING_WEIGHTING_SUM },
                { IMX412_BINNING_TYPE, 0x02 },
                { IMX412_BINNING_TYPE_EXT_EN, 0x01 },
                { IMX412_BINNING_TYPE_H_EXT, 0x01 },
                { IMX412_BLACKLEVEL_ENABLE, 0x01 }
        BINNING_END(ctrl->binnings[5])

        ctrl->max_binning_modes_used = 5;

        ctrl->flags                     = FLAG_RESET_ALWAYS;
        ctrl->flags                    |= FLAG_EXPOSURE_NORMAL;
        ctrl->flags                    |= FLAG_INCREASE_FRAME_RATE;
        ctrl->flags                    |= FLAG_IO_ENABLED;
        ctrl->flags                    |= FLAG_TRIGGER_SLAVE;
        ctrl->flags                    |= FLAG_USE_BINNING_INDEX;
}

// ------------------------------------------------------------------------------------------------
//  Settings for IMX415C (Rev.02)
//  8.3 MegaPixel Starvis

static void vc_init_ctrl_imx415(struct vc_ctrl *ctrl, struct vc_desc* desc)
{
        INIT_MESSAGE("IMX415")

        AGAIN_LIN(240, 72000)

        ctrl->csr.sen.blacklevel        = (vc_csr2) { .l = 0x30e2, .m = 0x30e3 };
        ctrl->csr.sen.hmax              = (vc_csr4) { .l = 0x3028, .m = 0x3029, .h = 0x0000, .u = 0x0000 };
        ctrl->csr.sen.vmax              = (vc_csr4) { .l = 0x3024, .m = 0x3025, .h = 0x3026, .u = 0x0000 };
        ctrl->csr.sen.mode_standby      = 0x01;
        ctrl->csr.sen.mode_operating    = 0x00;

        FRAME(0, 0, 3840, 2160)
        // All read out      binning     hmax  hmax    hmax  vmax      vmax   vmax  blkl  blkl  retrigger
        //                      mode      min   max     def   min       max    def   max   def
        MODE_HMAX( 0, 2, FORMAT_RAW10, 0, 1042, 0xffff, 1042,    8,  0xfffff, 0x8ca, 1023,   50,         0)
        MODE_HMAX( 1, 4, FORMAT_RAW10, 0,  521, 0xffff,  521,    8,  0xfffff, 0x8ca, 1023,   50,         0)
        VMAX_MARGIN(0, 1, 46, 1222)
        VMAX_MARGIN(1, 1, 46, 1222)

        ctrl->clk_pixel                 = 74250000;

        ctrl->flags                     = FLAG_EXPOSURE_SONY;
        ctrl->flags                    |= FLAG_INCREASE_FRAME_RATE;
        ctrl->flags                    |= FLAG_DOUBLE_HEIGHT;
        ctrl->flags                    |= FLAG_FORMAT_GBRG;
        ctrl->flags                    |= FLAG_IO_ENABLED;
}

// -------------------------------------------------------------
//  Settings for IMX462 (Rev.01)
//  2.0 MegaPixel Starvis

static void vc_init_ctrl_imx462(struct vc_ctrl *ctrl, struct vc_desc *desc)
{
        INIT_MESSAGE("IMX462")

        vc_init_ctrl_imx290_base(ctrl, desc);

        // All read out      binning    hmax  vmax      vmax   vmax  blkl  blkl  retrigger
        //                      mode           min       max    def   max   def
        MODE( 0, 2, FORMAT_RAW10, 0,    1100,    1,  0x3ffff, 0x465,  511,   60,         0)
        MODE( 1, 4, FORMAT_RAW10, 0,     550,    1,  0x3ffff, 0x465,  511,   60,         0)
        MODE( 2, 2, FORMAT_RAW12, 0,    2200,    1,  0x3ffff, 0x465,  511,   60,         0)
        VMAX_MARGIN(0, 1, 19, 0)
        VMAX_MARGIN(1, 1, 19, 0)
        VMAX_MARGIN(2, 1, 19, 0)

}

#define IMX56X_HV_MODE                  0x303c
#define IMX56X_BINNING_MODE_DISABLE     0x00
#define IMX56X_BINNING_MODE_ENABLE      0x10
#define IMX56X_VBLK_HWIDTH_UPPER        0x30d1
#define IMX56X_VBLK_HWIDTH_LOWER        0x30d0
#define IMX56X_FINFO_HWIDTH_UPPER       0x30d3
#define IMX56X_FINFO_HWIDTH_LOWER       0x30d2
#define IMX56X_EAV_SELECT               0x3942
#define IMX56X_EAV_SELECT_VALUE         0x03

#define IMX56X_GMRWT                    0x30e2
#define IMX56X_GMTWT                    0x30e3
#define IMX56X_GAINDLY                  0x30e5
#define IMX56X_GSDLY                    0x30e6

// ------------------------------------------------------------------------------------------------
//  Settings for IMX565 (Rev.03)
//  12.4 MegaPixel Pregius S

static void vc_init_ctrl_imx565(struct vc_ctrl *ctrl, struct vc_desc *desc)
{
        INIT_MESSAGE("IMX565")

        AGAIN_LIN(480, 48000)
        
        ctrl->csr.sen.again             = (vc_csr2) { .l = 0x3514, .m = 0x3515 };
        ctrl->csr.sen.blacklevel        = (vc_csr2) { .l = 0x35b4, .m = 0x35b5 };
        ctrl->csr.sen.vmax              = (vc_csr4) { .l = 0x30d4, .m = 0x30d5, .h = 0x30d6, .u = 0x0000 };
        ctrl->csr.sen.hmax              = (vc_csr4) { .l = 0x30d8, .m = 0x30d9, .h = 0x0000, .u = 0x0000 };
        ctrl->csr.sen.mode              = (vc_csr2) { .l = 0x3000, .m = 0x3010 };
        ctrl->csr.sen.mode_standby      = 0x01;
        ctrl->csr.sen.mode_operating    = 0x00;

        FRAME(0, 0, 4128, 3000)

        //                              binning  hmax  hmax    hmax  vmax vmax        vmax  blkl  blkl  retrigger
        //                                       min    max     def  min  max          def   max   def
        MODE_HMAX( 0, 2, FORMAT_RAW08, 0,       1070, 0xffff, 1070,   18, 0xffffff,   0xc2c,  255,   15,   2410776)
        MODE_HMAX( 1, 2, FORMAT_RAW10, 0,       1328, 0xffff, 1328,   16, 0xffffff,   0xc2a, 1023,   60,   2990142)
        MODE_HMAX( 2, 2, FORMAT_RAW12, 0,       1586, 0xffff, 1586,   14, 0xffffff,   0xc26, 4095,  240,   3568752)
        MODE_HMAX( 3, 4, FORMAT_RAW08, 0,        555, 0xffff,  555,   30, 0xffffff,   0xc40,  255,   15,   1256094)
        MODE_HMAX( 4, 4, FORMAT_RAW10, 0,        684, 0xffff,  684,   26, 0xffffff,   0xc3a, 1023,   60,   1546074)
        MODE_HMAX( 5, 4, FORMAT_RAW12, 0,        812, 0xffff,  812,   22, 0xffffff,   0xc34, 4095,  240,   1833030)

        // Binning
        MODE_HMAX( 6, 2, FORMAT_RAW08, 1,        554, 0xffff,  554,   32, 0xffffff,   0x644,  255,   15,    638982)
        MODE_HMAX( 7, 2, FORMAT_RAW10, 1,        683, 0xffff,  683,   28, 0xffffff,   0x640, 1023,   60,    785808)
        MODE_HMAX( 8, 2, FORMAT_RAW12, 1,        812, 0xffff,  812,   24, 0xffffff,   0x638, 4095,  240,    931878)
        MODE_HMAX( 9, 4, FORMAT_RAW08, 1,        297, 0xffff,  297,   52, 0xffffff,   0x668,  255,   15,    347760)
        MODE_HMAX(10, 4, FORMAT_RAW10, 1,        361, 0xffff,  361,   44, 0xffffff,   0x65c, 1023,   60,    420552)
        MODE_HMAX(11, 4, FORMAT_RAW12, 1,        425, 0xffff,  425,   40, 0xffffff,   0x654, 4095,  240,    493884)
        VMAX_MARGIN(0, 1, 116, 0)
        VMAX_MARGIN(1, 1, 114, 0)
        VMAX_MARGIN(2, 1, 110, 0)
        VMAX_MARGIN(3, 1, 136, 0)
        VMAX_MARGIN(4, 1, 130, 0)
        VMAX_MARGIN(5, 1, 124, 0)
        VMAX_MARGIN(6, 1, 104, 0)
        VMAX_MARGIN(7, 1, 100, 0)
        VMAX_MARGIN(8, 1, 92, 0)
        VMAX_MARGIN(9, 1, 140, 0)
        VMAX_MARGIN(10, 1, 128, 0)
        VMAX_MARGIN(11, 1, 120, 0)

        // Special registers for binning mode
        BINNING_MODE_REGS(  6, { IMX56X_GMRWT, 0x04 }, { IMX56X_GMTWT, 0x1c }, { IMX56X_GAINDLY, 0x04 }, { IMX56X_GSDLY, 0x0c } );
        BINNING_MODE_REGS(  7, { IMX56X_GMRWT, 0x04 }, { IMX56X_GMTWT, 0x18 }, { IMX56X_GAINDLY, 0x04 }, { IMX56X_GSDLY, 0x0c } );
        BINNING_MODE_REGS(  8, { IMX56X_GMRWT, 0x04 }, { IMX56X_GMTWT, 0x14 }, { IMX56X_GAINDLY, 0x04 }, { IMX56X_GSDLY, 0x08 } );
        BINNING_MODE_REGS(  9, { IMX56X_GMRWT, 0x08 }, { IMX56X_GMTWT, 0x30 }, { IMX56X_GAINDLY, 0x04 }, { IMX56X_GSDLY, 0x18 } );
        BINNING_MODE_REGS( 10, { IMX56X_GMRWT, 0x08 }, { IMX56X_GMTWT, 0x28 }, { IMX56X_GAINDLY, 0x04 }, { IMX56X_GSDLY, 0x14 } );
        BINNING_MODE_REGS( 11, { IMX56X_GMRWT, 0x08 }, { IMX56X_GMTWT, 0x24 }, { IMX56X_GAINDLY, 0x04 }, { IMX56X_GSDLY, 0x10 } );

        BINNING_START(ctrl->binnings[0], 0, 0)
                { IMX56X_HV_MODE, IMX56X_BINNING_MODE_DISABLE },
                { IMX56X_EAV_SELECT, IMX56X_EAV_SELECT_VALUE }
        BINNING_END(ctrl->binnings[0])

        BINNING_START(ctrl->binnings[1], 2, 2)
                { IMX56X_HV_MODE, IMX56X_BINNING_MODE_ENABLE },
                { IMX56X_EAV_SELECT, IMX56X_EAV_SELECT_VALUE }
        BINNING_END(ctrl->binnings[1])

        ctrl->max_binning_modes_used = 1;

        ctrl->flags                     = FLAG_EXPOSURE_SONY;
        ctrl->flags                    |= FLAG_PREGIUS_S;
        ctrl->flags                    |= FLAG_USE_BINNING_INDEX;
        ctrl->flags                    |= FLAG_INCREASE_FRAME_RATE;
        ctrl->flags                    |= FLAG_IO_ENABLED;
        ctrl->flags                    |= FLAG_TRIGGER_EXTERNAL | FLAG_TRIGGER_PULSEWIDTH | 
                                          FLAG_TRIGGER_SELF | FLAG_TRIGGER_SINGLE;
}

// ------------------------------------------------------------------------------------------------
//  Settings for IMX566 (Rev.03)
//  8.3 MegaPixel Pregius S

static void vc_init_ctrl_imx566(struct vc_ctrl *ctrl, struct vc_desc* desc)
{
        INIT_MESSAGE("IMX566")

        AGAIN_LIN(480, 48000)

        ctrl->csr.sen.blacklevel        = (vc_csr2) { .l = 0x35b4, .m = 0x35b5 };
        ctrl->csr.sen.vmax              = (vc_csr4) { .l = 0x30d4, .m = 0x30d5, .h = 0x30d6, .u = 0x0000 };
        ctrl->csr.sen.hmax              = (vc_csr4) { .l = 0x30d8, .m = 0x30d9, .h = 0x0000, .u = 0x0000 };
        ctrl->csr.sen.mode              = (vc_csr2) { .l = 0x3000, .m = 0x3010 };
        ctrl->csr.sen.mode_standby      = 0x01;
        ctrl->csr.sen.mode_operating    = 0x00;

        FRAME(0, 0, 2848, 2848)

        // All read out      binning  hmax    hmax     hmax  vmax      vmax   vmax  blkl  blkl  retrigger
        //                      mode   min      max      def   min       max    def   max   def
        MODE_HMAX( 0, 2, FORMAT_RAW08, 0,     752, 0xffff,   752,   24, 0xffffff, 0xb98,  255,   15,   1612278)
        MODE_HMAX( 1, 2, FORMAT_RAW10, 0,     930, 0xffff,   930,   20, 0xffffff, 0xb92, 1023,   60,   1991196)
        MODE_HMAX( 2, 2, FORMAT_RAW12, 0,    1109, 0xffff,  1109,   18, 0xffffff, 0xb8c, 4095,  240,   2371194)
        MODE_HMAX( 3, 4, FORMAT_RAW08, 0,     396, 0xffff,   396,   40, 0xffffff, 0xbb0,  255,   15,    854172)
        MODE_HMAX( 4, 4, FORMAT_RAW10, 0,     485, 0xffff,   485,   34, 0xffffff, 0xba6, 1023,   60,   1043334)
        MODE_HMAX( 5, 4, FORMAT_RAW12, 0,     574, 0xffff,   574,   30, 0xffffff, 0xba0, 4095,  240,   1233144)

        // Binning
        MODE_HMAX( 6, 2, FORMAT_RAW08, 1,     396, 0xffff,   396,   40, 0xffffff, 0x604,  255,   15,    430812)
        MODE_HMAX( 7, 2, FORMAT_RAW10, 1,     485, 0xffff,   485,   36, 0xffffff, 0x5fc, 1023,   60,    524826)
        MODE_HMAX( 8, 2, FORMAT_RAW12, 1,     575, 0xffff,   575,   32, 0xffffff, 0x5f4, 4095,  240,    620568)
        MODE_HMAX( 9, 4, FORMAT_RAW08, 1,     218, 0xffff,   218,   72, 0xffffff, 0x634,  255,   15,    242892)
        MODE_HMAX(10, 4, FORMAT_RAW10, 1,     262, 0xffff,   262,   60, 0xffffff, 0x620, 1023,   60,    288846)
        MODE_HMAX(11, 4, FORMAT_RAW12, 1,     307, 0xffff,   307,   52, 0xffffff, 0x614, 4095,  240,    336690)
        VMAX_MARGIN(0, 1, 120, 0)
        VMAX_MARGIN(1, 1, 114, 0)
        VMAX_MARGIN(2, 1, 108, 0)
        VMAX_MARGIN(3, 1, 144, 0)
        VMAX_MARGIN(4, 1, 134, 0)
        VMAX_MARGIN(5, 1, 128, 0)
        VMAX_MARGIN(6, 1, 116, 0)
        VMAX_MARGIN(7, 1, 108, 0)
        VMAX_MARGIN(8, 1, 100, 0)
        VMAX_MARGIN(9, 1, 164, 0)
        VMAX_MARGIN(10, 1, 144, 0)
        VMAX_MARGIN(11, 1, 132, 0)

        // Special registers for binning mode
        BINNING_MODE_REGS(  6, { IMX56X_GMRWT, 0x08 }, { IMX56X_GMTWT, 0x24 }, { IMX56X_GAINDLY, 0x04 }, { IMX56X_GSDLY, 0x10 } );
        BINNING_MODE_REGS(  7, { IMX56X_GMRWT, 0x04 }, { IMX56X_GMTWT, 0x20 }, { IMX56X_GAINDLY, 0x04 }, { IMX56X_GSDLY, 0x10 } );
        BINNING_MODE_REGS(  8, { IMX56X_GMRWT, 0x04 }, { IMX56X_GMTWT, 0x1c }, { IMX56X_GAINDLY, 0x04 }, { IMX56X_GSDLY, 0x0c } );
        BINNING_MODE_REGS(  9, { IMX56X_GMRWT, 0x0c }, { IMX56X_GMTWT, 0x44 }, { IMX56X_GAINDLY, 0x04 }, { IMX56X_GSDLY, 0x1c } );
        BINNING_MODE_REGS( 10, { IMX56X_GMRWT, 0x08 }, { IMX56X_GMTWT, 0x38 }, { IMX56X_GAINDLY, 0x04 }, { IMX56X_GSDLY, 0x18 } );
        BINNING_MODE_REGS( 11, { IMX56X_GMRWT, 0x08 }, { IMX56X_GMTWT, 0x30 }, { IMX56X_GAINDLY, 0x04 }, { IMX56X_GSDLY, 0x14 } );

        BINNING_START(ctrl->binnings[0], 0, 0)
                { IMX56X_HV_MODE, IMX56X_BINNING_MODE_DISABLE },
                { IMX56X_EAV_SELECT, IMX56X_EAV_SELECT_VALUE }
        BINNING_END(ctrl->binnings[0])

        BINNING_START(ctrl->binnings[1], 2, 2)
                { IMX56X_HV_MODE, IMX56X_BINNING_MODE_ENABLE },
                { IMX56X_EAV_SELECT, IMX56X_EAV_SELECT_VALUE }
        BINNING_END(ctrl->binnings[1])

        ctrl->max_binning_modes_used = 1;

        ctrl->flags                     = FLAG_EXPOSURE_SONY;
        ctrl->flags                    |= FLAG_PREGIUS_S;
        ctrl->flags                    |= FLAG_USE_BINNING_INDEX;
        ctrl->flags                    |= FLAG_INCREASE_FRAME_RATE;
        ctrl->flags                    |= FLAG_IO_ENABLED;
        ctrl->flags                    |= FLAG_TRIGGER_EXTERNAL | FLAG_TRIGGER_PULSEWIDTH |
                                          FLAG_TRIGGER_SELF | FLAG_TRIGGER_SINGLE;
}

// ------------------------------------------------------------------------------------------------
//  Settings for IMX567 (Rev.03)
//  5.1 MegaPixel Pregius S

static void vc_init_ctrl_imx567(struct vc_ctrl *ctrl, struct vc_desc* desc)
{
        INIT_MESSAGE("IMX567")

        AGAIN_LIN(480, 48000)

        ctrl->csr.sen.blacklevel        = (vc_csr2) { .l = 0x35b4, .m = 0x35b5 };
        ctrl->csr.sen.vmax              = (vc_csr4) { .l = 0x30d4, .m = 0x30d5, .h = 0x30d6, .u = 0x0000 };
        ctrl->csr.sen.hmax              = (vc_csr4) { .l = 0x30d8, .m = 0x30d9, .h = 0x0000, .u = 0x0000 };
        ctrl->csr.sen.mode              = (vc_csr2) { .l = 0x3000, .m = 0x3010 };
        ctrl->csr.sen.mode_standby      = 0x01;
        ctrl->csr.sen.mode_operating    = 0x00;

        FRAME(0, 0, 2464, 2064)

        // All read out      binning    hmax  vmax      vmax   vmax  blkl  blkl  retrigger
        //                      mode           min       max    def   max   def
        MODE( 0, 2, FORMAT_RAW08, 0,     656,   26, 0xffffff, 0x88a,  255,   15,   1058562)
        MODE( 1, 2, FORMAT_RAW10, 0,     810,   22, 0xffffff, 0x884, 1023,   60,   1273590)
        MODE( 2, 2, FORMAT_RAW12, 0,     965,   20, 0xffffff, 0x880, 4095,  240,   1514484)
        MODE( 3, 4, FORMAT_RAW08, 0,     348,   46, 0xffffff, 0x8a8,  255,   15,    553716)
        MODE( 4, 4, FORMAT_RAW10, 0,     425,   38, 0xffffff, 0x89e, 1023,   60,    673812)
        MODE( 5, 4, FORMAT_RAW12, 0,     502,   34, 0xffffff, 0x896, 4095,  240,    793692)
        VMAX_MARGIN(0, 1, 120, 0)
        VMAX_MARGIN(1, 1, 114, 0)
        VMAX_MARGIN(2, 1, 108, 0)
        VMAX_MARGIN(3, 1, 144, 0)
        VMAX_MARGIN(4, 1, 134, 0)
        VMAX_MARGIN(5, 1, 128, 0)

        // Binning
        MODE( 6, 2, FORMAT_RAW08, 1,     348,   48, 0xffffff, 0x488,  255,   15,    285444)
        MODE( 7, 2, FORMAT_RAW10, 1,     425,   40, 0xffffff, 0x47c, 1023,   60,    346140)
        MODE( 8, 2, FORMAT_RAW12, 1,     503,   36, 0xffffff, 0x474, 4095,  240,    406782)
        MODE( 9, 4, FORMAT_RAW08, 1,     194,   80, 0xffffff, 0x4b8,  255,   15,    164214)
        MODE(10, 4, FORMAT_RAW10, 1,     232,   68, 0xffffff, 0x4a8, 1023,   60,    194346)
        MODE(11, 4, FORMAT_RAW12, 1,     271,   60, 0xffffff, 0x498, 4095,  240,    224640)
        VMAX_MARGIN(6, 1, 116, 0)
        VMAX_MARGIN(7, 1, 108, 0)
        VMAX_MARGIN(8, 1, 100, 0)
        VMAX_MARGIN(9, 1, 164, 0)
        VMAX_MARGIN(10, 1, 144, 0)
        VMAX_MARGIN(11, 1, 132, 0)

        // Special registers for binning mode
        BINNING_MODE_REGS(  6, { IMX56X_GMRWT, 0x08 }, { IMX56X_GMTWT, 0x2c }, { IMX56X_GAINDLY, 0x04 }, { IMX56X_GSDLY, 0x14 } );
        BINNING_MODE_REGS(  7, { IMX56X_GMRWT, 0x08 }, { IMX56X_GMTWT, 0x24 }, { IMX56X_GAINDLY, 0x04 }, { IMX56X_GSDLY, 0x10 } );
        BINNING_MODE_REGS(  8, { IMX56X_GMRWT, 0x04 }, { IMX56X_GMTWT, 0x20 }, { IMX56X_GAINDLY, 0x04 }, { IMX56X_GSDLY, 0x10 } );
        BINNING_MODE_REGS(  9, { IMX56X_GMRWT, 0x0c }, { IMX56X_GMTWT, 0x4c }, { IMX56X_GAINDLY, 0x04 }, { IMX56X_GSDLY, 0x20 } );
        BINNING_MODE_REGS( 10, { IMX56X_GMRWT, 0x0c }, { IMX56X_GMTWT, 0x40 }, { IMX56X_GAINDLY, 0x04 }, { IMX56X_GSDLY, 0x1c } );
        BINNING_MODE_REGS( 11, { IMX56X_GMRWT, 0x08 }, { IMX56X_GMTWT, 0x38 }, { IMX56X_GAINDLY, 0x04 }, { IMX56X_GSDLY, 0x18 } );

        BINNING_START(ctrl->binnings[0], 0, 0)
                { IMX56X_HV_MODE, IMX56X_BINNING_MODE_DISABLE },
                { IMX56X_EAV_SELECT, IMX56X_EAV_SELECT_VALUE }
        BINNING_END(ctrl->binnings[0])

        BINNING_START(ctrl->binnings[1], 2, 2)
                { IMX56X_HV_MODE, IMX56X_BINNING_MODE_ENABLE },
                { IMX56X_EAV_SELECT, IMX56X_EAV_SELECT_VALUE }
        BINNING_END(ctrl->binnings[1])

        ctrl->max_binning_modes_used = 1;

        ctrl->flags                     = FLAG_EXPOSURE_SONY;
        ctrl->flags                    |= FLAG_PREGIUS_S;
        ctrl->flags                    |= FLAG_USE_BINNING_INDEX;
        ctrl->flags                    |= FLAG_INCREASE_FRAME_RATE;
        ctrl->flags                    |= FLAG_IO_ENABLED;
        ctrl->flags                    |= FLAG_TRIGGER_EXTERNAL | FLAG_TRIGGER_PULSEWIDTH |
                                          FLAG_TRIGGER_SELF | FLAG_TRIGGER_SINGLE;
        ctrl->flags                    |= FLAG_USE_BINNING_INDEX;
}

// ------------------------------------------------------------------------------------------------
//  Settings for IMX568 (Rev.04)
//  5.1 MegaPixel Pregius S
//
// NOTES:
// - Changed hmax from 348 to 370 for 4 lanes and RAW08.
//   This reduces frame rate from 97.1 to 90.6 fps.
//   Currently this is tested and necessary for i.MX8M Plus.

static void vc_init_ctrl_imx568(struct vc_ctrl *ctrl, struct vc_desc* desc)
{
        INIT_MESSAGE("IMX568")

        AGAIN_LIN(480, 48000)

        ctrl->csr.sen.blacklevel        = (vc_csr2) { .l = 0x35b4, .m = 0x35b5 };
        ctrl->csr.sen.vmax              = (vc_csr4) { .l = 0x30d4, .m = 0x30d5, .h = 0x30d6, .u = 0x0000 };
        ctrl->csr.sen.hmax              = (vc_csr4) { .l = 0x30d8, .m = 0x30d9, .h = 0x0000, .u = 0x0000 };
        ctrl->csr.sen.mode              = (vc_csr2) { .l = 0x3000, .m = 0x3010 };
        ctrl->csr.sen.mode_standby      = 0x01;
        ctrl->csr.sen.mode_operating    = 0x00;

        FRAME(0, 0, 2464, 2064)
        // All read out      binning  hmax    hmax     hmax  vmax      vmax   vmax  blkl  blkl  retrigger
        //                      mode   min      max      def   min       max    def   max   def
        MODE_HMAX( 0, 2, FORMAT_RAW08, 0,     656, 0xffff,   656,   26, 0xffffff, 0x88a,  255,   15,   1058562)
        MODE_HMAX( 1, 2, FORMAT_RAW10, 0,     810, 0xffff,   810,   22, 0xffffff, 0x884, 1023,   60,   1273590)
        MODE_HMAX( 2, 2, FORMAT_RAW12, 0,     965, 0xffff,   965,   20, 0xffffff, 0x880, 4095,  240,   1514484)
        MODE_HMAX( 3, 4, FORMAT_RAW08, 0,     348, 0xffff,   370,   46, 0xffffff, 0x8a8,  255,   15,    553716)
        MODE_HMAX( 4, 4, FORMAT_RAW10, 0,     425, 0xffff,   425,   38, 0xffffff, 0x89e, 1023,   60,    673812)
        MODE_HMAX( 5, 4, FORMAT_RAW12, 0,     502, 0xffff,   502,   34, 0xffffff, 0x896, 4095,  240,    793692)

        // Binning
        MODE_HMAX( 6, 2, FORMAT_RAW08, 1,     348, 0xffff,   348,   48, 0xffffff, 0x488,  255,   15,    285444)
        MODE_HMAX( 7, 2, FORMAT_RAW10, 1,     425, 0xffff,   425,   40, 0xffffff, 0x47c, 1023,   60,    346140)
        MODE_HMAX( 8, 2, FORMAT_RAW12, 1,     503, 0xffff,   503,   36, 0xffffff, 0x474, 4095,  240,    406782)
        MODE_HMAX( 9, 4, FORMAT_RAW08, 1,     194, 0xffff,   194,   80, 0xffffff, 0x4b8,  255,   15,    164214)
        MODE_HMAX(10, 4, FORMAT_RAW10, 1,     232, 0xffff,   232,   68, 0xffffff, 0x4a8, 1023,   60,    194346)
        MODE_HMAX(11, 4, FORMAT_RAW12, 1,     271, 0xffff,   271,   60, 0xffffff, 0x498, 4095,  240,    224640)
        VMAX_MARGIN(0, 1, 122, 0)
        VMAX_MARGIN(1, 1, 116, 0)
        VMAX_MARGIN(2, 1, 112, 0)
        VMAX_MARGIN(3, 1, 152, 0)
        VMAX_MARGIN(4, 1, 142, 0)
        VMAX_MARGIN(5, 1, 134, 0)
        VMAX_MARGIN(6, 1, 128, 0)
        VMAX_MARGIN(7, 1, 116, 0)
        VMAX_MARGIN(8, 1, 108, 0)
        VMAX_MARGIN(9, 1, 176, 0)
        VMAX_MARGIN(10, 1, 160, 0)
        VMAX_MARGIN(11, 1, 144, 0)

        // Special registers for binning mode
        BINNING_MODE_REGS(  6, { IMX56X_GMRWT, 0x08 }, { IMX56X_GMTWT, 0x2c }, { IMX56X_GAINDLY, 0x04 }, { IMX56X_GSDLY, 0x14 } );
        BINNING_MODE_REGS(  7, { IMX56X_GMRWT, 0x08 }, { IMX56X_GMTWT, 0x24 }, { IMX56X_GAINDLY, 0x04 }, { IMX56X_GSDLY, 0x10 } );
        BINNING_MODE_REGS(  8, { IMX56X_GMRWT, 0x04 }, { IMX56X_GMTWT, 0x20 }, { IMX56X_GAINDLY, 0x04 }, { IMX56X_GSDLY, 0x10 } );
        BINNING_MODE_REGS(  9, { IMX56X_GMRWT, 0x0c }, { IMX56X_GMTWT, 0x4c }, { IMX56X_GAINDLY, 0x04 }, { IMX56X_GSDLY, 0x20 } );
        BINNING_MODE_REGS( 10, { IMX56X_GMRWT, 0x0c }, { IMX56X_GMTWT, 0x40 }, { IMX56X_GAINDLY, 0x04 }, { IMX56X_GSDLY, 0x1c } );
        BINNING_MODE_REGS( 11, { IMX56X_GMRWT, 0x08 }, { IMX56X_GMTWT, 0x38 }, { IMX56X_GAINDLY, 0x04 }, { IMX56X_GSDLY, 0x18 } );

        BINNING_START(ctrl->binnings[0], 0, 0)
                { IMX56X_HV_MODE, IMX56X_BINNING_MODE_DISABLE },
                { IMX56X_EAV_SELECT, IMX56X_EAV_SELECT_VALUE }
        BINNING_END(ctrl->binnings[0])

        BINNING_START(ctrl->binnings[1], 2, 2)
                { IMX56X_HV_MODE, IMX56X_BINNING_MODE_ENABLE },
                { IMX56X_EAV_SELECT, IMX56X_EAV_SELECT_VALUE }
        BINNING_END(ctrl->binnings[1])

        ctrl->max_binning_modes_used = 1;

        ctrl->flags                     = FLAG_EXPOSURE_SONY;
        ctrl->flags                    |= FLAG_PREGIUS_S;
        ctrl->flags                    |= FLAG_USE_BINNING_INDEX;
        ctrl->flags                    |= FLAG_INCREASE_FRAME_RATE;
        ctrl->flags                    |= FLAG_IO_ENABLED;
        ctrl->flags                    |= FLAG_TRIGGER_EXTERNAL | FLAG_TRIGGER_PULSEWIDTH |
                                          FLAG_TRIGGER_SELF | FLAG_TRIGGER_SINGLE;
        ctrl->flags                    |= FLAG_USE_BINNING_INDEX;
}
// ------------------------------------------------------------------------------------------------
//  Settings for IMX585 (Rev.01)
//  8.4 MegaPixel Starvis 2

static void vc_init_ctrl_imx585(struct vc_ctrl *ctrl, struct vc_desc* desc)
{
        INIT_MESSAGE("IMX585")


        AGAIN_LIN(240, 72000)
        
        ctrl->csr.sen.blacklevel        = (vc_csr2) { .l = 0x30dc, .m = 0x30dd };
        ctrl->csr.sen.hmax              = (vc_csr4) { .l = 0x302c, .m = 0x302d, .h = 0x0000, .u = 0x0000 };
        ctrl->csr.sen.vmax              = (vc_csr4) { .l = 0x3028, .m = 0x3029, .h = 0x302a, .u = 0x0000 };
        ctrl->csr.sen.mode_standby      = 0x01;
        ctrl->csr.sen.mode_operating    = 0x00;
        ctrl->flags                     = FLAG_EXPOSURE_SONY;
        ctrl->flags                    |= FLAG_INCREASE_FRAME_RATE;
        ctrl->flags                    |= FLAG_IO_ENABLED;
        // No trigger support for IMX585

                                         

        FRAME(0, 0, 3840, 2160)
        //                              binning  hmax  hmax    hmax  vmax vmax      vmax    blkl  blkl  retrigger
        //                                       min    max     def  min  max        def     max   def
        MODE_HMAX( 0, 2, FORMAT_RAW10, 0,       1100, 0xffff, 1100,    8,  0x1ffff,  0x08ca,  0x3ff,   0x32,   0)
        MODE_HMAX( 1, 2, FORMAT_RAW12, 0,       1100, 0xffff, 1100,    8,  0x1ffff,  0x08ca,  0x3ff,   0x32,   0)
        MODE_HMAX( 2, 4, FORMAT_RAW10, 0,        550, 0xffff,  550,    8,  0x1ffff,  0x08ca,  0x3ff,   0x32,   0)
        MODE_HMAX( 3, 4, FORMAT_RAW12, 0,        550, 0xffff,  550,    8,  0x1ffff,  0x08ca,  0x3ff,   0x32,   0)
        VMAX_MARGIN(0, 1, 70, 1024)
        VMAX_MARGIN(1, 1, 70, 1024)
        VMAX_MARGIN(2, 1, 70, 1024)
        VMAX_MARGIN(3, 1, 70, 1024)
}

// ------------------------------------------------------------------------------------------------
//  Settings for IMX900 (Rev.02)
//  3.2 MegaPixel Pregius S

static void vc_init_ctrl_imx900(struct vc_ctrl *ctrl, struct vc_desc* desc)
{
        INIT_MESSAGE("IMX900")

        AGAIN_LIN(480, 48000)

        ctrl->csr.sen.blacklevel        = (vc_csr2) { .l = 0x35b4, .m = 0x35b5 };
        ctrl->csr.sen.vmax              = (vc_csr4) { .l = 0x30d4, .m = 0x30d5, .h = 0x30d6, .u = 0x0000 };
        ctrl->csr.sen.hmax              = (vc_csr4) { .l = 0x30d8, .m = 0x30d9, .h = 0x0000, .u = 0x0000 };
        ctrl->csr.sen.mode              = (vc_csr2) { .l = 0x3000, .m = 0x3010 };
        ctrl->csr.sen.mode_standby      = 0x01;
        ctrl->csr.sen.mode_operating    = 0x00;

        FRAME(0, 0, 2048, 1536)

        // All read out      binning    hmax  vmax      vmax   vmax  blkl  blkl  retrigger
        //                      mode           min       max    def   max   def
        MODE( 0, 2, FORMAT_RAW08, 0,     571,   99, 0xffffff, 1794,   255,  15,    563060)
        MODE( 1, 2, FORMAT_RAW10, 0,     700,   99, 0xffffff, 1794,  1023,  60,    688284)
        MODE( 2, 2, FORMAT_RAW12, 0,     829,   99, 0xffffff, 1794,  4095, 240,    795528)
        MODE( 3, 4, FORMAT_RAW08, 0,     338,   99, 0xffffff, 1794,   255,  15,    413694)
        MODE( 4, 4, FORMAT_RAW10, 0,     378,   99, 0xffffff, 1794,  1023,  60,    444204)
        MODE( 5, 4, FORMAT_RAW12, 0,     610,   99, 0xffffff, 1794,  4095, 240,    727542)
        VMAX_MARGIN(0, 1, 258, 1794)
        VMAX_MARGIN(1, 1, 258, 1794)
        VMAX_MARGIN(2, 1, 258, 1794)
        VMAX_MARGIN(3, 1, 258, 1794)
        VMAX_MARGIN(4, 1, 258, 1794)
        VMAX_MARGIN(5, 1, 258, 1794)

        ctrl->flags                     = FLAG_EXPOSURE_SONY;

        ctrl->flags                    |= FLAG_PREGIUS_S;
        ctrl->flags                    |= FLAG_INCREASE_FRAME_RATE;
        ctrl->flags                    |= FLAG_IO_ENABLED;
        ctrl->flags                    |= FLAG_TRIGGER_EXTERNAL | FLAG_TRIGGER_PULSEWIDTH |
                                          FLAG_TRIGGER_SELF | FLAG_TRIGGER_SINGLE;

        BINNING_START(ctrl->binnings[0], 0, 0)
                { IMX56X_HV_MODE, IMX56X_BINNING_MODE_DISABLE },
                { IMX56X_EAV_SELECT, IMX56X_EAV_SELECT_VALUE }
        BINNING_END(ctrl->binnings[0])
}

// ------------------------------------------------------------------------------------------------
//  Settings for OV7251 (Rev.01)
//  0.3 MegaPixel OmniPixel3-GS
//
//  TODO: 
//  - No flash out

static void vc_init_ctrl_ov7251(struct vc_ctrl *ctrl, struct vc_desc* desc)
{
        INIT_MESSAGE("OV7251")

        ctrl->exposure                  = (vc_control) { .min =   1, .max =   1000000, .def =  10000 };
        AGAIN_FRA(255, 12000)

        ctrl->csr.sen.h_end             = (vc_csr2) { .l = 0x0000, .m = 0x0000 };
        ctrl->csr.sen.v_end             = (vc_csr2) { .l = 0x0000, .m = 0x0000 };
        ctrl->csr.sen.flash_duration    = (vc_csr4) { .l = 0x3b8f, .m = 0x3b8e, .h = 0x3b8d, .u = 0x3b8c };
        ctrl->csr.sen.flash_offset      = (vc_csr4) { .l = 0x3b8b, .m = 0x3b8a, .h = 0x3b89, .u = 0x3b88 };
        ctrl->csr.sen.vmax              = (vc_csr4) { .l = 0x380f, .m = 0x380e, .h = 0x0000, .u = 0x0000 };
        // NOTE: Modules rom table contains swapped address assigment.
        ctrl->csr.sen.again             = (vc_csr2) { .l = 0x350b, .m = 0x350a };
        
        FRAME(0, 0, 640, 480)
        // All read out      binning    hmax  vmax      vmax   vmax  blkl  blkl  retrigger
        //                      mode           min       max    def   max   def
        MODE( 0, 1, FORMAT_RAW08, 0,     772,    0,   0xffff,   598,    0,    0,         0)
        MODE( 1, 1, FORMAT_RAW10, 0,     772,    0,   0xffff,   598,    0,    0,         0)

        ctrl->flash_factor              = 1758241 >> 4; // (1000 << 4)/9100 >> 4
        ctrl->flash_toffset             = 4;

        ctrl->flags                     = FLAG_EXPOSURE_OMNIVISION;
        ctrl->flags                    |= FLAG_IO_ENABLED;
        // Prior shared hardcoded value, unchanged -- see the field comment
        // in vc_mipi_core.h.
        ctrl->vmax_exposure_margin      = 25;
}

// ------------------------------------------------------------------------------------------------
//  Settings for OV9281 (Rev.03)
//  1.02 MegaPixel OmniPixel3-GS

static void vc_init_ctrl_ov9281(struct vc_ctrl *ctrl, struct vc_desc* desc)
{
        INIT_MESSAGE("OV9281")
        
        ctrl->exposure                  = (vc_control) { .min = 146, .max =    595000, .def =  10000 };
        AGAIN_FRA(255, 12000)

        ctrl->csr.sen.h_end             = (vc_csr2) { .l = 0x0000, .m = 0x0000 };
        ctrl->csr.sen.v_end             = (vc_csr2) { .l = 0x0000, .m = 0x0000 };
        ctrl->csr.sen.flash_duration	= (vc_csr4) { .l = 0x3928, .m = 0x3927, .h = 0x3926, .u = 0x3925 };
        ctrl->csr.sen.flash_offset      = (vc_csr4) { .l = 0x3924, .m = 0x3923, .h = 0x3922, .u = 0x0000 };
        // TIMING_HTS: Total Horizontal Timing Size in SYS_CLK (80 MHz) cycles.
        // Default 0x02D8 = 728 = 9100 ns line period.  Freely programmable
        // (no fixed-value restriction unlike Sony sensors).
        ctrl->csr.sen.hmax              = (vc_csr4) { .l = 0x380d, .m = 0x380c, .h = 0x0000, .u = 0x0000 };
        ctrl->csr.sen.vmax              = (vc_csr4) { .l = 0x380f, .m = 0x380e, .h = 0x0000, .u = 0x0000 };
        // NOTE: Modules rom table contains swapped address assigment.
        ctrl->csr.sen.again             = (vc_csr2) { .l = 0x3509, .m = 0x0000 };
        
        FRAME(0, 0, 1280, 800)
        // All read out      binning   hmax    hmax     hmax  vmax      vmax   vmax  blkl  blkl  retrigger
        //                      mode   min      max      def   min       max    def   max   def
        // HTS domain: SYS_CLK = 80 MHz.  hmax_min = hmax_def = 728 (= 9100 ns, the
        // minimum at full resolution 1280x800 limited by MIPI line xmit time).
        MODE_HMAX( 0, 2, FORMAT_RAW08, 0,     728, 0xffff,   728,   16,   0xffff,   910,    0,    0,         0)
        MODE_HMAX( 1, 2, FORMAT_RAW10, 0,     728, 0xffff,   728,   16,   0xffff,   910,    0,    0,         0)
        VMAX_MARGIN(0, 1, 0, 910)
        VMAX_MARGIN(1, 1, 0, 910)

        // SYS_CLK = 80 MHz (PLL1, table 2-11 in OV9281 datasheet).
        // HTS register (0x380C/0x380D) is in SYS_CLK cycles.
        // CAUTION: old value was 40 MHz / hmax=364 — same period (364/40 = 728/80 = 9.1 µs)
        //          but writing hmax to the register requires the correct 80 MHz domain.
        ctrl->clk_ext_trigger           = 80000000;
        ctrl->clk_pixel                 = 80000000;

        ctrl->flash_factor              = 1758241 >> 4; // (1000 << 4)/9100 >> 4
        ctrl->flash_toffset             = 4;

        ctrl->flags                     = FLAG_EXPOSURE_OMNIVISION;
        ctrl->flags                    |= FLAG_IO_ENABLED;
        ctrl->flags                    |= FLAG_TRIGGER_EXTERNAL;
        ctrl->flags                    |= FLAG_INCREASE_FRAME_RATE;
        ctrl->vmax_exposure_margin      = 25;
}


// ------------------------------------------------------------------------------------------------
//  Settings for AR2020 (Rev.01)
//  20 MegaPixel Rolling shutter

static void vc_init_ctrl_ar2020(struct vc_ctrl *ctrl, struct vc_desc* desc)
{
        INIT_MESSAGE("AR2020")


        ctrl->clk_pixel                 = desc->clk_pixel * 8;

        ctrl->csr.sen.hmax              = (vc_csr4) { .l = 0x0343, .m = 0x0342, .h = 0x0000, .u = 0x0000 };
        ctrl->csr.sen.vmax              = (vc_csr4) { .l = 0x0341, .m = 0x0340, .h = 0x0000, .u = 0x0000 };


        ctrl->exposure                  = (vc_control) { .min = 146, .max =    595000, .def =   1000 };

        AGAIN_LIN(80, 30000)

        FRAME(0, 0, 5120, 3840)
        // All read out      binning   hmax    hmax     hmax  vmax      vmax   vmax  blkl  blkl  retrigger
        //                      mode   min      max      def   min       max    def   max   def
        //
       
        MODE_HMAX( 0, 4, FORMAT_RAW08, 0,   20000,  0xffff, 20000,    4,   0xffff,  3870,    0,    0,         0)
        MODE_HMAX( 1, 4, FORMAT_RAW10, 0,   20000,  0xffff, 20000,    4,   0xffff,  3870,    0,    0,         0)
        MODE_HMAX( 2, 4, FORMAT_RAW12, 0,   25200,   25200, 25200,    4,   0xffff,  3870,    0,    0,         0)
        MODE_HMAX( 3, 2, FORMAT_RAW08, 0,   44800,   44800, 44800,    4,   0xffff,  3870,    0,    0,         0)
        MODE_HMAX( 4, 2, FORMAT_RAW10, 0,   44800,   44800, 44800,    4,   0xffff,  3870,    0,    0,         0)
        MODE_HMAX( 5, 2, FORMAT_RAW12, 0,   44800,   44800, 44800,    4,   0xffff,  3870,    0,    0,         0)

        VMAX_MARGIN(0, 1, 0, 3870)
        VMAX_MARGIN(1, 1, 0, 3870)
        VMAX_MARGIN(2, 1, 0, 3870)
        VMAX_MARGIN(3, 1, 0, 3870)
        VMAX_MARGIN(4, 1, 0, 3870)
        VMAX_MARGIN(5, 1, 0, 3870)

      
        EXTRA_MODE_REGS(2, { 0x0342, 0x62 }, { 0x0343, 0x70 }, { 0x0220, 0x00 })
        EXTRA_MODE_REGS(5, { 0x0220, 0x00 })

        ctrl->flags                     = FLAG_EXPOSURE_NORMAL;
        ctrl->flags                    |= FLAG_IO_ENABLED;

        ctrl->vmax_exposure_margin      = 4;
       // ctrl->flags                    |= FLAG_TRIGGER_EXTERNAL; 
        ctrl->flags                    |= FLAG_INCREASE_FRAME_RATE;
        ctrl->flags                    |= FLAG_FORMAT_GRBG;
        
        ctrl->crop_top_step             = 2;

}

int vc_mod_ctrl_init(struct vc_ctrl* ctrl, struct vc_desc* desc)
{
        struct device *dev = &ctrl->client_mod->dev;

        vc_init_ctrl(ctrl, desc);

        switch(desc->mod_id) {
        case MOD_ID_IMX178: vc_init_ctrl_imx178(ctrl, desc); break;
        case MOD_ID_IMX183: vc_init_ctrl_imx183(ctrl, desc); break;
        case MOD_ID_IMX226: vc_init_ctrl_imx226(ctrl, desc); break;
        case MOD_ID_IMX250: vc_init_ctrl_imx250(ctrl, desc); break;
        case MOD_ID_IMX252: vc_init_ctrl_imx252(ctrl, desc); break;
        case MOD_ID_IMX264: vc_init_ctrl_imx264(ctrl, desc); break;
        case MOD_ID_IMX265: vc_init_ctrl_imx265(ctrl, desc); break;
        case MOD_ID_IMX273: vc_init_ctrl_imx273(ctrl, desc); break;
        case MOD_ID_IMX290: vc_init_ctrl_imx290(ctrl, desc); break;
        case MOD_ID_IMX296: vc_init_ctrl_imx296(ctrl, desc); break;
        case MOD_ID_IMX297: vc_init_ctrl_imx297(ctrl, desc); break;
        case MOD_ID_IMX327: vc_init_ctrl_imx327(ctrl, desc); break;
        case MOD_ID_IMX335: vc_init_ctrl_imx335(ctrl, desc); break;
        case MOD_ID_IMX392: vc_init_ctrl_imx392(ctrl, desc); break;
        case MOD_ID_IMX412: vc_init_ctrl_imx412(ctrl, desc); break;
        case MOD_ID_IMX415: vc_init_ctrl_imx415(ctrl, desc); break;
        case MOD_ID_IMX462: vc_init_ctrl_imx462(ctrl, desc); break;
        case MOD_ID_IMX565: vc_init_ctrl_imx565(ctrl, desc); break;
        case MOD_ID_IMX566: vc_init_ctrl_imx566(ctrl, desc); break;
        case MOD_ID_IMX567: vc_init_ctrl_imx567(ctrl, desc); break;
        case MOD_ID_IMX568: vc_init_ctrl_imx568(ctrl, desc); break;
        case MOD_ID_IMX585: vc_init_ctrl_imx585(ctrl, desc); break;
        case MOD_ID_IMX900: vc_init_ctrl_imx900(ctrl, desc); break;
        case MOD_ID_OV7251: vc_init_ctrl_ov7251(ctrl, desc); break;
        case MOD_ID_OV9281: vc_init_ctrl_ov9281(ctrl, desc); break;
        case MOD_ID_AR2020: vc_init_ctrl_ar2020(ctrl, desc); break;
        default:
                vc_err(dev, "%s(): Detected module not supported!\n", __FUNCTION__);
                return 1;
        }

        return 0;
}
EXPORT_SYMBOL(vc_mod_ctrl_init);