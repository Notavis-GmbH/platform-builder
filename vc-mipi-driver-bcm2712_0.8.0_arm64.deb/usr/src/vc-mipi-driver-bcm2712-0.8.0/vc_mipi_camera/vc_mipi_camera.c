#include "../vc_mipi_core/vc_mipi_core.h"
#include <linux/module.h>
#include <linux/gpio/consumer.h>
#include <linux/pm_runtime.h>
#include <linux/version.h>
#include <linux/of_graph.h>
#include <linux/property.h> // For device_property_read_bool()

#include <media/v4l2-subdev.h>
#include <media/v4l2-ctrls.h>
#include <media/v4l2-fwnode.h>
#include <media/v4l2-event.h>

#define VERSION_CAMERA "0.8.0"

int debug = 3;
// --- Prototypes --------------------------------------------------------------
static int vc_sd_s_power(struct v4l2_subdev *sd, int on);
static int vc_sd_s_ctrl(struct v4l2_subdev *sd, struct v4l2_control *control);
static int vc_suspend(struct device *dev);
static int vc_resume(struct device *dev);
int vc_sd_enum_mbus_code(struct v4l2_subdev *sd, struct v4l2_subdev_state *state, struct v4l2_subdev_mbus_code_enum *code);
int vc_sd_enum_frame_size(struct v4l2_subdev *sd, struct v4l2_subdev_state *state, struct v4l2_subdev_frame_size_enum *fse);
static int vc_sd_get_fmt(struct v4l2_subdev *sd, struct v4l2_subdev_state *state, struct v4l2_subdev_format *fmt);
static int vc_sd_set_fmt(struct v4l2_subdev *sd, struct v4l2_subdev_state *state, struct v4l2_subdev_format *fmt);
static int vc_sd_get_selection(struct v4l2_subdev *sd, struct v4l2_subdev_state *state, struct v4l2_subdev_selection *sel);
static int vc_sd_set_selection(struct v4l2_subdev *sd, struct v4l2_subdev_state *state, struct v4l2_subdev_selection *sel);
int vc_sd_open(struct v4l2_subdev *sd, struct v4l2_subdev_fh *fh);
void vc_sd_close(struct v4l2_subdev *sd, struct v4l2_subdev_fh *fh);
int vc_sd_queryctrl(struct v4l2_subdev *sd, struct v4l2_queryctrl *qc);
int vc_sd_g_ctrl(struct v4l2_subdev *sd, struct v4l2_control *control);
int vc_sd_s_ctrl(struct v4l2_subdev *sd, struct v4l2_control *control);
int vc_sd_querymenu(struct v4l2_subdev *sd, struct v4l2_querymenu *qm);
int vc_sd_g_mbus_config(struct v4l2_subdev *sd, struct v4l2_mbus_config *cfg);
int vc_sd_s_mbus_config(struct v4l2_subdev *sd, struct v4l2_mbus_config *cfg);
int vc_ctrl_s_ctrl(struct v4l2_ctrl *ctrl);
static vc_mode *vc_get_mode(struct vc_cam *cam);

// --- Structures --------------------------------------------------------------

enum private_cids
{
        V4L2_CID_VC_TRIGGER_MODE = V4L2_CID_USER_BASE | 0xfff0, // TODO FOR NOW USE 0xfff0 offset
        V4L2_CID_VC_IO_MODE,
        V4L2_CID_VC_FRAME_RATE,
        V4L2_CID_VC_SINGLE_TRIGGER,
        V4L2_CID_VC_BINNING_MODE,
        V4L2_CID_LIVE_ROI,
        V4L2_CID_VC_INFO,
};

enum pad_types
{
        IMAGE_PAD,
        METADATA_PAD,
        NUM_PADS
};
struct vc_control_int_menu
{
        struct v4l2_ctrl *ctrl;
        const struct v4l2_ctrl_ops *ops;
};
struct vc_device
{
        struct v4l2_subdev sd;
        struct v4l2_ctrl_handler ctrl_handler;
        struct media_pad pad;
        int power_on;
        struct mutex mutex;
        struct v4l2_rect crop_rect;
        struct v4l2_mbus_framefmt format;
        struct vc_cam cam;
        bool libcamera_enabled;
        u32 force_color_mode;
        __u32 supported_mbus_codes[MAX_MBUS_CODES];
        struct v4l2_ctrl *hblank_ctrl;
        struct v4l2_ctrl *vblank_ctrl;
        struct v4l2_ctrl *blacklevel_ctrl;
        struct v4l2_ctrl *pixel_rate_ctrl;
        struct v4l2_ctrl *gain_ctrl;
};
static void vc_update_clk_rates(struct vc_device *device, struct vc_cam *cam);
static void vc_update_blacklevel_ctrl(struct vc_device *device, struct vc_cam *cam);

static inline struct vc_device *to_vc_device(struct v4l2_subdev *sd)
{
        return container_of(sd, struct vc_device, sd);
}

static inline struct vc_cam *to_vc_cam(struct v4l2_subdev *sd)
{
        struct vc_device *device = to_vc_device(sd);
        return &device->cam;
}

static struct vc_control hblank;
static struct vc_control vblank;
static struct vc_control pixel_rate;
// Unsupported mbus codes for libcamera
static int unsupported_mbus_codes[1] =
    {
        MEDIA_BUS_FMT_Y14_1X14};

static struct vc_control64 linkfreq = {
    .min = 0,
    .max = 0,
    .def = 0,
};

static void update_frame_rate_ctrl(struct vc_cam *cam, struct vc_device *device);
int vc_sd_update_fmt(struct vc_device *device);

static void vc_get_binning_scale(struct vc_cam *cam, __u8 *h_scale, __u8 *v_scale)
{
        struct vc_binning *binning = vc_core_get_binning(cam);

        *h_scale = binning->h_factor == 0 ? 1 : binning->h_factor;
        *v_scale = binning->v_factor == 0 ? 1 : binning->v_factor;
}
// Libcamera does not support all mbus codes, so we need to filter them out
static void vc_init_supported_mbus_codes(struct vc_device *device)
{
        struct vc_cam *cam = &device->cam;
        struct device *dev = &device->cam.ctrl.client_sen->dev;

        int i, j, counter = 0;

        for (i = 0; i < MAX_MBUS_CODES; i++)
        {
                device->supported_mbus_codes[i] = 0;
        }

        for (i = 0; i < MAX_MBUS_CODES; i++)
        {
                if (device->libcamera_enabled)
                {
                        for (j = 0; j < ARRAY_SIZE(unsupported_mbus_codes); j++)
                        {
                                if (cam->ctrl.mbus_codes[i] == unsupported_mbus_codes[j])
                                {
                                        vc_dbg(dev, "%s(): Skipping unsupported mbus code: 0x%04x\n", __func__, cam->ctrl.mbus_codes[i]);
                                        goto skip_code;
                                }
                        }
                }
                if (cam->ctrl.mbus_codes[i] > 0)
                {
                        vc_notice(dev, "%s(): Adding mbus code: 0x%04x\n", __func__, cam->ctrl.mbus_codes[i]);
                        device->supported_mbus_codes[counter] = cam->ctrl.mbus_codes[i];
                        counter++;
                }

        skip_code:;
        }
}
// --- v4l2_subdev_core_ops ---------------------------------------------------

static void vc_set_power(struct vc_device *device, int on)
{
        struct device *dev = &device->cam.ctrl.client_sen->dev;

        if (device->power_on == on)
                return;

        vc_dbg(dev, "%s(): Set power: %s\n", __func__, on ? "on" : "off");

        // if (device->power_gpio)
        //         gpiod_set_value_cansleep(device->power_gpio, on);

        // if (on == 1) {
        //         vc_core_wait_until_device_is_ready(&device->cam, 1000);
        // }
        device->power_on = on;
}

static int vc_sd_s_power(struct v4l2_subdev *sd, int on)
{
        struct vc_device *device = to_vc_device(sd);

        mutex_lock(&device->mutex);

        vc_set_power(to_vc_device(sd), on);

        mutex_unlock(&device->mutex);

        return 0;
}

static int __maybe_unused vc_suspend(struct device *dev)
{
        struct i2c_client *client = to_i2c_client(dev);
        struct v4l2_subdev *sd = i2c_get_clientdata(client);
        struct vc_device *device = to_vc_device(sd);
        struct vc_state *state = &device->cam.state;

        vc_dbg(dev, "%s()\n", __func__);

        mutex_lock(&device->mutex);

        if (state->streaming)
                vc_sen_stop_stream(&device->cam);

        vc_set_power(device, 0);

        mutex_unlock(&device->mutex);

        return 0;
}

static int __maybe_unused vc_resume(struct device *dev)
{
        struct i2c_client *client = to_i2c_client(dev);
        struct v4l2_subdev *sd = i2c_get_clientdata(client);
        struct vc_device *device = to_vc_device(sd);

        vc_dbg(dev, "%s()\n", __func__);

        mutex_lock(&device->mutex);

        vc_set_power(device, 1);

        mutex_unlock(&device->mutex);

        return 0;
}

static int vc_sd_s_ctrl(struct v4l2_subdev *sd, struct v4l2_control *control)
{
        struct vc_cam *cam = to_vc_cam(sd);
        struct device *dev = vc_core_get_sen_device(cam);
        struct vc_device *device = to_vc_device(sd);
        int ret = 0;
        vc_mode *mode = vc_get_mode(cam);
        int num_lanes = mode ? mode->num_lanes : 0;
        switch (control->id)
        {

        case V4L2_CID_HBLANK:
        {
                u32 clk_pixel = cam->ctrl.clk_pixel;
                if (clk_pixel > 0 && pixel_rate.max > 0)
                {
                        u32 active_width = cam->state.frame.width > 0
                                               ? cam->state.frame.width
                                               : cam->ctrl.frame.width;
                        u32 new_hmax = (u32)div_u64(
                            (u64)(active_width + control->value) * clk_pixel,
                            pixel_rate.max);
                        vc_core_set_hmax_overwrite(cam, new_hmax);
                }
                else
                {
                        /* Align hblank to lane boundary (num_lanes is power of 2) */
                        u32 aligned_hblank = control->value & ~(num_lanes - 1);
                        vc_core_set_hmax_overwrite(cam, mode->hmax.def + aligned_hblank / num_lanes);
                }
                vc_notice(dev, "%s(): Set HBLANK: %d\n", __func__, control->value);
                vc_sen_set_hmax(cam);
                return 0;
        }

        case V4L2_CID_VBLANK:
        {
                /* Use the active (crop) height, not the full sensor native height.
                 * Frame period is VMAX x 1H for every sensor — FLAG_DOUBLE_HEIGHT
                 * affects ROI geometry, not the VMAX line total, so VMAX is simply
                 * active_height + vblank. */
                u32 active_height = cam->state.frame.height > 0
                                        ? cam->state.frame.height
                                        : cam->ctrl.frame.height;
                vc_core_set_vmax_overwrite(cam, active_height + control->value);
                vc_sen_write_vmax(&cam->ctrl, cam->state.vmax_overwrite);
                return 0;
        }
        case V4L2_CID_HFLIP:
        case V4L2_CID_VFLIP:
                return 0; // Currently not planned to be implemented

        case V4L2_CID_EXPOSURE:
                if (device->libcamera_enabled)
                {
                        // libcamera's unit for exposure is in lines count
                        return vc_sen_set_exposure(cam, control->value * vc_core_get_time_per_line_ns(cam) / 1000);
                }
                else
                {
                        return vc_sen_set_exposure(cam, control->value);
                }

        case V4L2_CID_ANALOGUE_GAIN:
        case V4L2_CID_GAIN:
                return vc_sen_set_gain(cam, control->value, true);

        case V4L2_CID_BLACK_LEVEL:
                return vc_sen_set_blacklevel(cam, control->value);
        case V4L2_CID_VC_TRIGGER_MODE:
                return vc_mod_set_trigger_mode(cam, control->value);

        case V4L2_CID_VC_IO_MODE:
                return vc_mod_set_io_mode(cam, control->value);

        case V4L2_CID_VC_FRAME_RATE:

                ret = vc_core_set_framerate(cam, control->value);
                vc_update_clk_rates(device, cam);
                return ret;

        case V4L2_CID_VC_SINGLE_TRIGGER:
                return vc_mod_set_single_trigger(cam);

        case V4L2_CID_VC_BINNING_MODE:
                ret = vc_core_set_binning_mode(cam, control->value);
                vc_sd_update_fmt(device);
                vc_update_blacklevel_ctrl(device, cam);
                return ret;

        case V4L2_CID_LIVE_ROI:
                return vc_core_live_roi(cam, control->value);

        default:
                vc_warn(dev, "%s(): Unknown control 0x%08x\n", __func__, control->id);
                return -EINVAL;
        }

        return 0;
}

// --- v4l2_subdev_video_ops ---------------------------------------------------

static int vc_sd_s_stream(struct v4l2_subdev *sd, int enable)
{
        struct vc_device *device = to_vc_device(sd);
        struct vc_cam *cam = to_vc_cam(sd);
        struct vc_state *state = &cam->state;
        struct device *dev = sd->dev;
        int ret = 0;

        vc_dbg(dev, "%s(): Set streaming: %s\n", __func__, enable ? "on" : "off");

        if (state->streaming == enable)
                return 0;

        mutex_lock(&device->mutex);
        if (enable)
        {
                ret = pm_runtime_get_sync(dev);
                if (ret < 0)
                {
                        vc_err(dev, "%s(): pm_runtime_get_sync failed: %d\n", __func__, ret);
                        pm_runtime_put_noidle(dev);
                        goto err_unlock;
                }

                ret = vc_sen_start_stream(cam);
                if (ret < 0)
                {
                        vc_err(dev, "%s(): Failed to start stream: %d\n", __func__, ret);
                        goto err_rpm_put;
                }


                vc_update_clk_rates(device, cam);
                update_frame_rate_ctrl(cam, device);
        }
        else
        {
                vc_sen_stop_stream(cam);
                pm_runtime_put(dev);
        }

        state->streaming = enable;
        mutex_unlock(&device->mutex);

        return 0;
err_rpm_put:
        vc_sen_stop_stream(cam);
        pm_runtime_put(dev);
err_unlock:
        mutex_unlock(&device->mutex);
        return ret;
}

// --- v4l2_subdev_pad_ops ---------------------------------------------------

static int vc_sd_get_fmt(struct v4l2_subdev *sd, struct v4l2_subdev_state *state, struct v4l2_subdev_format *format)
{
        struct vc_device *device = to_vc_device(sd);
        struct vc_cam *cam = to_vc_cam(sd);
        struct v4l2_mbus_framefmt *mf = &format->format;
        struct vc_frame *frame = NULL;

        mutex_lock(&device->mutex);

        mf->code = vc_core_get_format(cam);
        frame = vc_core_get_frame(cam);

        mf->width = frame->width;
        mf->height = frame->height;
        mf->field = V4L2_FIELD_NONE;
        mf->colorspace = V4L2_COLORSPACE_SRGB;

        mutex_unlock(&device->mutex);

        return 0;
}

static int vc_sd_set_fmt(struct v4l2_subdev *sd, struct v4l2_subdev_state *state, struct v4l2_subdev_format *format)
{
        struct vc_device *device = to_vc_device(sd);
        struct vc_cam *cam = to_vc_cam(sd);
        struct v4l2_mbus_framefmt *mf = &format->format;

        mutex_lock(&device->mutex);

        vc_core_set_format(cam, mf->code);
        vc_core_set_frame(cam, 0, 0, mf->width, mf->height);
        mf->field = V4L2_FIELD_NONE;
        mf->colorspace = V4L2_COLORSPACE_SRGB;

      
        vc_update_clk_rates(device, cam);

        mutex_unlock(&device->mutex);

        return 0;
}

int vc_sd_enum_mbus_code(struct v4l2_subdev *sd, struct v4l2_subdev_state *state, struct v4l2_subdev_mbus_code_enum *code)
{
        struct vc_device *device = to_vc_device(sd);
        int i;
        for (i = 0; i < MAX_MBUS_CODES; i++)
        {
                if (device->supported_mbus_codes[i] == 0)
                        break;
        }

        if (code->pad >= NUM_PADS)
                return -EINVAL;
        if (code->pad == IMAGE_PAD)
        {
                if (code->index >= i)
                        return -EINVAL;
                code->code = device->supported_mbus_codes[code->index];
        }
        else
        {
                if (code->index > 0)
                        return -EINVAL;

                code->code = MEDIA_BUS_FMT_SENSOR_DATA;
        }

        return 0;
}

int vc_sd_enum_frame_size(struct v4l2_subdev *sd, struct v4l2_subdev_state *cfg, struct v4l2_subdev_frame_size_enum *fse)
{
        struct vc_device *device = to_vc_device(sd);
        struct vc_cam *cam = to_vc_cam(sd);
        __u8 h_scale, v_scale;
        vc_get_binning_scale(cam, &h_scale, &v_scale);
        vc_frame *frame = &cam->ctrl.frame;
        int codeIx;
        if (fse->index != 0)
                return -EINVAL;

        mutex_lock(&device->mutex);

        bool format_supported = false;

        for (codeIx = 0; codeIx < ARRAY_SIZE(device->supported_mbus_codes); codeIx++)
        {
                if (device->supported_mbus_codes[codeIx] == fse->code)
                {
                        format_supported = true;
                        break;
                }
        }

        if (!format_supported)
        {
                mutex_unlock(&device->mutex);
                return -EINVAL;
        }

        // Frame sizes are the same for different formats

        fse->min_width = 32;
        fse->max_width = frame->width / h_scale;
        fse->min_height = 32;
        fse->max_height = frame->height / v_scale;

        mutex_unlock(&device->mutex);

        return 0;
}

static int vc_sd_get_selection(struct v4l2_subdev *sd,
                               struct v4l2_subdev_state *cfg,
                               struct v4l2_subdev_selection *sel)
{
        struct vc_cam *cam = to_vc_cam(sd);
        struct vc_device *device = to_vc_device(sd);
        struct vc_frame *frame = vc_core_get_frame(cam);
        struct vc_frame *frame_bounds = &cam->ctrl.frame;

        mutex_lock(&device->mutex);

        switch (sel->target)
        {
        case V4L2_SEL_TGT_CROP:
                sel->r.left = frame->left;
                sel->r.top = frame->top;
                sel->r.width = frame->width;
                sel->r.height = frame->height;
                break;
        case V4L2_SEL_TGT_CROP_DEFAULT:
        case V4L2_SEL_TGT_CROP_BOUNDS:
                sel->r.left = 0;
                sel->r.top = 0;
                sel->r.width = frame_bounds->width;
                sel->r.height = frame_bounds->height;
                break;
        }

        mutex_unlock(&device->mutex);

        return 0;
}

static int vc_sd_set_selection(struct v4l2_subdev *sd,
                               struct v4l2_subdev_state *cfg,
                               struct v4l2_subdev_selection *sel)
{
        struct vc_device *device = to_vc_device(sd);
        struct vc_cam *cam = to_vc_cam(sd);
        struct device *dev = &device->cam.ctrl.client_sen->dev;

        if (sel->target != V4L2_SEL_TGT_CROP)
                return -EINVAL;

        vc_core_set_frame(cam, sel->r.left, sel->r.top, sel->r.width, sel->r.height);

        vc_dbg(dev, "Rect: left=%d, top=%d, width=%d, height=%d\n",
               sel->r.left, sel->r.top, sel->r.width, sel->r.height);

        return 0;
}

// --- v4l2_ctrl_ops ---------------------------------------------------

int vc_ctrl_s_ctrl(struct v4l2_ctrl *ctrl)
{
        struct vc_device *device = container_of(ctrl->handler, struct vc_device, ctrl_handler);
        struct i2c_client *client = device->cam.ctrl.client_sen;
        struct v4l2_control control;

        // V4L2 controls values will be applied only when power is already up
        if (!pm_runtime_get_if_in_use(&client->dev))
        {
                vc_err(&client->dev, "%s(): Device is powered off, cannot set control 0x%08x\n", __func__, ctrl->id);
                return -ENODEV;
        }

        control.id = ctrl->id;
        control.value = ctrl->val;
        vc_sd_s_ctrl(&device->sd, &control);

        pm_runtime_put(&client->dev);

        return 0;
}

static int vc_ctrl_g_volatile_ctrl(struct v4l2_ctrl *ctrl)
{
        struct vc_device *device = container_of(ctrl->handler, struct vc_device, ctrl_handler);
        struct vc_cam *cam = &device->cam;
        if (ctrl->id == V4L2_CID_VC_INFO)
        {
                snprintf(ctrl->p_new.p_char, ctrl->maximum + 1, "%.10s REV.%04u",
                         device->cam.desc.sen_type, device->cam.desc.mod_rev);
                return 0;
        }
        if (ctrl->id == V4L2_CID_LIVE_ROI)
        {
                ctrl->val = cam->state.binning_mode * 100000000 +
                            cam->state.frame.left * 10000 +
                            cam->state.frame.top;
                return 0;
        }
        return -EINVAL;
}

static int vc_get_bit_depth(__u8 mipi_format)
{

        switch (mipi_format)
        {
        case FORMAT_RAW08:
                return 8;
        case FORMAT_RAW10:
                return 10;
        case FORMAT_RAW12:
                return 12;
        case FORMAT_RAW14:
                return 14;
        default:;
                break;
        }
        return 0;
}

// *** Initialisation *********************************************************

static int vc_check_hwcfg(struct vc_cam *cam, struct device *dev, struct vc_device *device)
{
        struct fwnode_handle *endpoint;
        struct v4l2_fwnode_endpoint ep_cfg = {
            .bus_type = V4L2_MBUS_CSI2_DPHY};
        int ret = -EINVAL;

        endpoint = fwnode_graph_get_next_endpoint(dev_fwnode(dev), NULL);
        if (!endpoint)
        {
                dev_err(dev, "Endpoint node not found!\n");
                return -EINVAL;
        }

        if (v4l2_fwnode_endpoint_alloc_parse(endpoint, &ep_cfg))
        {
                dev_err(dev, "Could not parse endpoint!\n");
                goto error_out;
        }

        if (device_property_read_bool(dev, "libcamera"))
        {
                device->libcamera_enabled = true;
                dev_info(dev, "libcamera support enabled\n");
        }
        else
        {
                dev_info(dev, "libcamera support disabled\n");
        }

        if (device_property_read_bool(dev, "force-color-mode"))
        {
                device->force_color_mode = 1;
                dev_info(dev, "force-color-mode enabled\n");
        }

        if (device_property_read_bool(dev, "reset-always"))
        {
                cam->ctrl.flags |= FLAG_RESET_ALWAYS;
                dev_info(dev, "reset-always enabled\n");
        }

        /* Set and check the number of MIPI CSI2 data lanes */
        ret = vc_core_set_num_lanes(cam, ep_cfg.bus.mipi_csi2.num_data_lanes);

error_out:
        v4l2_fwnode_endpoint_free(&ep_cfg);
        fwnode_handle_put(endpoint);

        return ret;
}

static const struct v4l2_subdev_core_ops vc_core_ops = {
    .s_power = vc_sd_s_power,
    .subscribe_event = v4l2_ctrl_subdev_subscribe_event,
    .unsubscribe_event = v4l2_event_subdev_unsubscribe,
};

static const struct v4l2_subdev_video_ops vc_video_ops = {
    .s_stream = vc_sd_s_stream,
};

static const struct v4l2_subdev_pad_ops vc_pad_ops = {
    .get_fmt = vc_sd_get_fmt,
    .set_fmt = vc_sd_set_fmt,
    .enum_mbus_code = vc_sd_enum_mbus_code,
    .enum_frame_size = vc_sd_enum_frame_size,
    .get_selection = vc_sd_get_selection,
    .set_selection = vc_sd_set_selection,
};

static const struct v4l2_subdev_ops vc_subdev_ops = {
    .core = &vc_core_ops,
    .video = &vc_video_ops,
    .pad = &vc_pad_ops,
};

static const struct v4l2_ctrl_ops vc_ctrl_ops = {
    .s_ctrl = vc_ctrl_s_ctrl,
    .g_volatile_ctrl = vc_ctrl_g_volatile_ctrl,
};

static int vc_ctrl_init_ctrl(struct vc_device *device, struct v4l2_ctrl_handler *hdl, int id, struct vc_control *control, int flags, struct v4l2_ctrl **out_ctrl)
{
        struct i2c_client *client = device->cam.ctrl.client_sen;
        struct device *dev = &client->dev;
        struct v4l2_ctrl *ctrl;

        ctrl = v4l2_ctrl_new_std(&device->ctrl_handler, &vc_ctrl_ops, id, control->min, control->max, 1, control->def);
        if (ctrl == NULL)
        {
                vc_err(dev, "%s(): Failed to init 0x%08x (%s) ctrl (min=%u max=%u def=%u): %d\n",
                        __func__, id, v4l2_ctrl_get_name(id) ? v4l2_ctrl_get_name(id) : "unknown",
                        control->min, control->max, control->def, device->ctrl_handler.error);
                return -EIO;
        }
        if (flags)
                ctrl->flags |= flags;
        if (out_ctrl)
                *out_ctrl = ctrl;

        return 0;
}

static int vc_ctrl_init_ctrl_special(struct vc_device *device, struct v4l2_ctrl_handler *hdl, int id, int min, int max, int def)
{
        struct i2c_client *client = device->cam.ctrl.client_sen;
        struct device *dev = &client->dev;
        struct v4l2_ctrl *ctrl;

        ctrl = v4l2_ctrl_new_std(&device->ctrl_handler, &vc_ctrl_ops, id, min, max, 1, def);
        if (ctrl == NULL)
        {
                vc_err(dev, "%s(): Failed to init 0x%08x (%s) ctrl (min=%d max=%d def=%d): %d\n",
                        __func__, id, v4l2_ctrl_get_name(id) ? v4l2_ctrl_get_name(id) : "unknown",
                        min, max, def, device->ctrl_handler.error);
                return -EIO;
        }

        return 0;
}

static int vc_ctrl_init_ctrl_lfreq(struct vc_device *device, struct v4l2_ctrl_handler *hdl, int id, struct vc_control64 *control)
{
        struct i2c_client *client = device->cam.ctrl.client_sen;
        struct device *dev = &client->dev;
        struct v4l2_ctrl *ctrl;

        // CAUTION: only ONE element in linkfreq array used !
        ctrl = v4l2_ctrl_new_int_menu(&device->ctrl_handler, &vc_ctrl_ops, id, 0, 0, &control->def);
        if (ctrl == NULL)
        {
                vc_err(dev, "%s(): Failed to init 0x%08x (%s) ctrl (def=%llu): %d\n",
                        __func__, id, v4l2_ctrl_get_name(id) ? v4l2_ctrl_get_name(id) : "unknown",
                        (unsigned long long)control->def, device->ctrl_handler.error);
                return -EIO;
        }

        if (ctrl)
                ctrl->flags |= V4L2_CTRL_FLAG_READ_ONLY;

        return 0;
}

// static int vc_ctrl_init_ctrl_std_menu(struct vc_device *device, struct v4l2_ctrl_handler *hdl, int id, const char * const items[], size_t items_count)
// {
//         struct i2c_client *client = device->cam.ctrl.client_sen;
//         struct device *dev = &client->dev;
//         struct v4l2_ctrl *ctrl;

//         for (size_t i = 0; i < items_count; i++) {
//             }
//         ctrl = v4l2_ctrl_new_std_menu_items(&device->ctrl_handler, &vc_ctrl_ops, id, items_count - 1, 0, 0, items);
//         if (ctrl == NULL)
//         {
//                 vc_err(dev, "%s(): Failed to init 0x%08x ctrl\n", __func__, id);
//                 return -EIO;
//         }

//         return 0;
// }

static int vc_ctrl_init_ctrl_lc(struct vc_device *device, struct v4l2_ctrl_handler *hdl)
{
        struct i2c_client *client = device->cam.ctrl.client_sen;
        struct device *dev = &client->dev;
        struct v4l2_fwnode_device_properties props;
        struct v4l2_ctrl *ctrl;
        int ret;

        ret = v4l2_fwnode_device_parse(dev, &props);
        if (ret < 0)
                return ret;

        vc_info(dev, "%s(): orientation=%d rotation=%d", __func__, props.orientation, props.rotation);

        ret = v4l2_ctrl_new_fwnode_properties(hdl, &vc_ctrl_ops, &props);
        if (ret < 0)
                vc_err(dev, "%s(): Failed to init fwnode ctrls ... will continue anyway\n", __func__);

        ctrl = v4l2_ctrl_new_std(hdl, &vc_ctrl_ops, V4L2_CID_HFLIP, 0, 1, 1, 0);
        if (ctrl == NULL)
                goto ctrl_err;

        ctrl = v4l2_ctrl_new_std(hdl, &vc_ctrl_ops, V4L2_CID_VFLIP, 0, 1, 1, 0);

ctrl_err:
        if (ctrl == NULL)
        {
                vc_err(dev, "%s(): Failed to init lc ctrls\n", __func__);
                return -EIO;
        }

        return 0;
}
static int vc_ctrl_init_custom_ctrl(struct vc_device *device, struct v4l2_ctrl_handler *hdl, const struct v4l2_ctrl_config *config, struct v4l2_ctrl **ctrl)
{
        struct i2c_client *client = device->cam.ctrl.client_sen;
        struct device *dev = &client->dev;

        *ctrl = v4l2_ctrl_new_custom(&device->ctrl_handler, config, NULL);
        if (*ctrl == NULL)
        {
                vc_err(dev, "%s(): Failed to init 0x%08x (%s) ctrl (min=%lld max=%lld def=%lld step=%llu): %d\n",
                        __func__, config->id, config->name ? config->name : "unknown",
                        config->min, config->max, config->def, config->step, device->ctrl_handler.error);
                return -EIO;
        }
        return 0;
}
static const struct v4l2_ctrl_config ctrl_rotation = {
    .ops = &vc_ctrl_ops,
    .id = V4L2_CID_CAMERA_SENSOR_ROTATION,
    .name = "Sensor rotation",
    .type = V4L2_CTRL_TYPE_INTEGER,
    .flags = V4L2_CTRL_FLAG_EXECUTE_ON_WRITE | V4L2_CTRL_FLAG_MODIFY_LAYOUT,
    .min = 0,
    .max = 360,
    .step = 1,
    .def = 0,
};

static const struct v4l2_ctrl_config ctrl_orientation = {
    .ops = &vc_ctrl_ops,
    .id = V4L2_CID_CAMERA_ORIENTATION,
    .name = "Sensor orientation",
    .type = V4L2_CTRL_TYPE_INTEGER,
    .flags = V4L2_CTRL_FLAG_EXECUTE_ON_WRITE,
    .min = 0,
    .max = 2,
    .step = 1,
    .def = V4L2_CAMERA_ORIENTATION_FRONT,
};

static const char *const trigger_mode_menu[] = {
    "Off",
    "External",
    "Pulse Width",
    "Self",
    "Single",
    "Sync",
    "Stream Edge",
    "Stream Level"};

static const struct v4l2_ctrl_config ctrl_trigger_mode = {
    .ops = &vc_ctrl_ops,
    .id = V4L2_CID_VC_TRIGGER_MODE,
    .name = "Trigger Mode",
    .type = V4L2_CTRL_TYPE_MENU,
    .flags = V4L2_CTRL_FLAG_EXECUTE_ON_WRITE,
    .min = 0,
    .max = ARRAY_SIZE(trigger_mode_menu) - 1,
    .def = 0,
    .qmenu = trigger_mode_menu,
};

/* "Off" (index 0) is accepted unconditionally by vc_mod_set_trigger_mode(),
 * every other entry requires the matching FLAG_TRIGGER_* bit the sensor
 * model advertised in vc_mipi_modules.c -- keep this in sync with the mode
 * checks there. */
static __u64 vc_trigger_mode_skip_mask(__u32 flags)
{
    __u64 mask = 0;

    if (!(flags & FLAG_TRIGGER_EXTERNAL))
        mask |= 1ULL << 1;
    if (!(flags & FLAG_TRIGGER_PULSEWIDTH))
        mask |= 1ULL << 2;
    if (!(flags & (FLAG_TRIGGER_SELF | FLAG_TRIGGER_SELF_V2)))
        mask |= 1ULL << 3;
    if (!(flags & FLAG_TRIGGER_SINGLE))
        mask |= 1ULL << 4;
    if (!(flags & (FLAG_TRIGGER_SYNC | FLAG_TRIGGER_SLAVE)))
        mask |= 1ULL << 5;
    if (!(flags & FLAG_TRIGGER_STREAM_EDGE))
        mask |= 1ULL << 6;
    if (!(flags & FLAG_TRIGGER_STREAM_LEVEL))
        mask |= 1ULL << 7;

    return mask;
}

static const char *const io_mode_menu[] = {
    "Off",
    "Flash Active High",
    "Flash Active Low",
    "Trigger Active Low",
    "Trigger Active Low / Flash Active High",
    "Trigger And Flash Active Low"};

static const struct v4l2_ctrl_config ctrl_flash_mode = {
    .ops = &vc_ctrl_ops,
    .id = V4L2_CID_VC_IO_MODE,
    .name = "IO Mode",
    .type = V4L2_CTRL_TYPE_MENU,
    .flags = V4L2_CTRL_FLAG_EXECUTE_ON_WRITE,
    .min = 0,
    .max = ARRAY_SIZE(io_mode_menu) - 1,
    .def = 0,
    .qmenu = io_mode_menu,
};

/* "Off" (index 0) is accepted unconditionally by vc_mod_set_io_mode(); every
 * other entry requires FLAG_IO_ENABLED on the sensor model -- keep this in
 * sync with the mode checks there. */
static __u64 vc_io_mode_skip_mask(__u32 flags)
{
    __u64 mask = 0;

    if (!(flags & FLAG_IO_ENABLED))
        mask |= (1ULL << 1) | (1ULL << 2) | (1ULL << 3) | (1ULL << 4) | (1ULL << 5);

    return mask;
}

static const struct v4l2_ctrl_config ctrl_frame_rate = {
    .ops = &vc_ctrl_ops,
    .id = V4L2_CID_VC_FRAME_RATE,
    .name = "Frame Rate",
    .type = V4L2_CTRL_TYPE_INTEGER,
    .flags = V4L2_CTRL_FLAG_EXECUTE_ON_WRITE,
    .min = 0,
    .max = 1000000,
    .step = 1,
    .def = 0,
};

static const struct v4l2_ctrl_config ctrl_single_trigger = {
    .ops = &vc_ctrl_ops,
    .id = V4L2_CID_VC_SINGLE_TRIGGER,
    .name = "Single Trigger",
    .type = V4L2_CTRL_TYPE_BUTTON,
    .flags = V4L2_CTRL_FLAG_EXECUTE_ON_WRITE,
    .min = 0,
    .max = 0,
    .step = 0,
    .def = 0,
};

static const struct v4l2_ctrl_config ctrl_binning_mode = {
    .ops = &vc_ctrl_ops,
    .id = V4L2_CID_VC_BINNING_MODE,
    .name = "Binning Mode",
    .type = V4L2_CTRL_TYPE_INTEGER,
    .flags = V4L2_CTRL_FLAG_EXECUTE_ON_WRITE | V4L2_CTRL_FLAG_MODIFY_LAYOUT,
    .min = 0,
    .max = 4,
    .step = 1,
    .def = 0,
};

static const struct v4l2_ctrl_config ctrl_live_roi = {
    .ops = &vc_ctrl_ops,
    .id = V4L2_CID_LIVE_ROI,
    .name = "Live Roi",
    .type = V4L2_CTRL_TYPE_INTEGER,
    .flags = V4L2_CTRL_FLAG_EXECUTE_ON_WRITE | V4L2_CTRL_FLAG_VOLATILE,
    .min = 0,
    .max = 999999999,
    .step = 1,
    .def = 0,
};

/* Non-const: def is updated by vc_update_clk_rates() to match the current mode */
static struct v4l2_ctrl_config ctrl_blacklevel = {
    .ops = &vc_ctrl_ops,
    .id = V4L2_CID_BLACK_LEVEL, // See https://github.com/VC-MIPI-modules/vc_mipi_nvidia/blob/master/doc/BLACK_LEVEL.md
    .name = "Black Level",
    .type = V4L2_CTRL_TYPE_INTEGER,
    .flags = V4L2_CTRL_FLAG_EXECUTE_ON_WRITE,
    .min = 0,
    .max = 100000,
    .step = 1,
    .def = 0,
};

static const struct v4l2_ctrl_config ctrl_name = {
    .ops = &vc_ctrl_ops,
    .id = V4L2_CID_VC_INFO,
    .name = "Sensor info",
    .type = V4L2_CTRL_TYPE_STRING,
    .flags = V4L2_CTRL_FLAG_READ_ONLY | V4L2_CTRL_FLAG_VOLATILE,
    .min = 0,
    .max = 19,
    .step = 1,
    .def = 0,
};

/* Non-const: min/max/def are updated by vc_update_clk_rates() before ctrl creation */
static struct v4l2_ctrl_config ctrl_hblank = {
    .ops = &vc_ctrl_ops,
    .id = V4L2_CID_HBLANK,
    .name = "Horizontal Blanking",
    .type = V4L2_CTRL_TYPE_INTEGER,
    .flags = V4L2_CTRL_FLAG_READ_ONLY,
    .min = 0,
    .max = 0,
    .step = 1,
    .def = 0,
};

/* Non-const: min/max/def are updated by vc_update_clk_rates() before ctrl creation */
static struct v4l2_ctrl_config ctrl_vblank = {
    .ops = &vc_ctrl_ops,
    .id = V4L2_CID_VBLANK,
    .name = "Vertical Blanking",
    .type = V4L2_CTRL_TYPE_INTEGER,
    .flags = 0,
    .min = 0,
    .max = 0,
    .step = 1,
    .def = 0,
};

static vc_mode *vc_get_mode(struct vc_cam *cam)
{
        /* Guard against the sentinel value 0xff set by vc_core_state_init
         * before a mode is formally selected.  Use ROM mode 0 as the
         * reference when state.mode is out of range. */
        __u8 safe_idx = (cam->state.mode < MAX_VC_DESC_MODES) ? cam->state.mode : 0;
        struct vc_desc_mode *mode_desc = &cam->desc.modes[safe_idx];
        vc_mode *mode = NULL;

        for (int i = 0; i < MAX_VC_MODES; i++)
        {
                if (mode_desc->format == cam->ctrl.mode[i].format &&
                    mode_desc->num_lanes == cam->ctrl.mode[i].num_lanes &&
                    mode_desc->binning == cam->ctrl.mode[i].binning)
                {
                        mode = &cam->ctrl.mode[i];
                        break;
                }
        }
        /* Fallback: if still no match (e.g. ROM mode 0 format/lanes not yet
         * reflected in ctrl modes), use the first valid ctrl mode. */
        if (!mode)
        {
                for (int i = 0; i < MAX_VC_MODES; i++)
                {
                        if (cam->ctrl.mode[i].num_lanes > 0)
                        {
                                mode = &cam->ctrl.mode[i];
                                break;
                        }
                }
        }
        return mode;
}

static void vc_update_clk_rates(struct vc_device *device, struct vc_cam *cam)
{
        vc_mode *mode = vc_get_mode(cam);
        if (!mode)
                return;
        /* Use the same safe index as vc_get_mode to avoid OOB when state.mode
         * is still the 0xff sentinel set by vc_core_state_init. */
        __u8 safe_mode_idx = (cam->state.mode < cam->desc.num_modes)
                                 ? cam->state.mode
                                 : 0;
        struct vc_desc_mode *mode_desc = &cam->desc.modes[safe_mode_idx];
        int num_lanes = mode->num_lanes;
        int bit_depth = vc_get_bit_depth(mode->format);
        u32 clk_pixel = cam->ctrl.clk_pixel;
        /* data_rate is stored in the ROM as a little-endian u32 in bps */
        u32 data_rate_mbps = (*(__u32 *)mode_desc->data_rate) / 1000000;

        /* CSI-2 DDR: serial bit rate per lane = data_rate_mbps.
         * Link frequency = serial bit rate / 2 (both edges of clock used). */
        linkfreq.max = (u64)data_rate_mbps * 1000000ULL / 2;
        linkfreq.def = linkfreq.max;
        linkfreq.min = linkfreq.max;

        /* Pixel rate = (data_rate_per_lane * num_lanes) / bits_per_pixel */
        pixel_rate.max = (u32)((u64)data_rate_mbps * num_lanes / bit_depth * 1000000);
        pixel_rate.def = pixel_rate.max;

        /* Compute actual vblank at the current operating point so that
         * seninf's calc_buffered_pixel_rate() gets a correct frame-line
         * count and sets its frame monitor to fire at the right interval.
         *
         * If a framerate is explicitly set, derive VMAX from the requested
         * frame period.  Otherwise use the crop-optimised VMAX (same logic
         * as vc_core_get_optimized_vmax). */
        {
                u32 height = cam->state.frame.height > 0
                                 ? cam->state.frame.height
                                 : cam->ctrl.frame.height;
                u32 vmax_actual;
                /* Frame period is VMAX x 1H for every sensor, including
                 * FLAG_DOUBLE_HEIGHT ones (e.g. IMX335, IMX415) — that flag
                 * affects ROI geometry, not the VMAX line total, so vmax.def/max
                 * are already in output-line units and need no extra scaling. */
                /* Datasheet-derived VMAX floor (VMAX >= height + margin, VMAX >= floor)
                 * takes precedence when a sensor mode specifies it; otherwise fall
                 * back to the generic vmax.def-based bound used for unresearched
                 * sensors. */
                if (mode->vmax_row_margin > 0 || mode->vmax_row_floor > 0)
                {
                        u32 vmax_min_real = height + mode->vmax_row_margin;
                        if (mode->vmax_row_floor > vmax_min_real)
                                vmax_min_real = mode->vmax_row_floor;
                        vblank.min = vmax_min_real > height ? vmax_min_real - height : 0;
                }
                else
                {
                        vblank.min = mode->vmax.def > height
                                         ? mode->vmax.def - height
                                         : 0;
                }
                vblank.max = mode->vmax.max > height
                                 ? mode->vmax.max - height
                                 : 0;

                if (cam->state.framerate > 0 && clk_pixel > 0)
                {
                        /* frame_period_ns = 1e12 / framerate_mHz */
                        u32 frame_period_ns = (u32)div_u64(1000000000000ULL,
                                                           cam->state.framerate);
                        u32 period_1H_ns = (u32)div_u64(
                            (u64)mode->hmax.def * 1000000000ULL,
                            clk_pixel);
                        /* frame_period / period_1H gives VMAX in output-line units. */
                        vmax_actual = period_1H_ns > 0
                                          ? (frame_period_ns / period_1H_ns)
                                          : mode->vmax.def;
                }
                else
                {
                        /* Native fps — apply crop optimisation in output-line units */
                        vmax_actual = mode->vmax.def;
                        if ((cam->ctrl.flags & FLAG_INCREASE_FRAME_RATE) &&
                            height < cam->ctrl.frame.height)
                                vmax_actual -= (cam->ctrl.frame.height - height);
                }

                vblank.def = vmax_actual > height
                                 ? vmax_actual - height
                                 : vblank.min;
                if (vblank.def < vblank.min)
                        vblank.def = vblank.min;

                /* seninf (MTK Genio) clamps calc_buffered_pixel_rate to an
                 * internal floor of ~408 MHz.  When (w+hb)*(h+vb)*fps < 408
                 * MHz the frame monitor fires early, causing PHY resyncs and
                 * wildly erratic frame delivery.
                 *
                 * Ensure the reported vblank is large enough that the
                 * product stays at or above the floor.  This only pads the
                 * V4L2 control value — the sensor VMAX register is set by
                 * vc_core and is unchanged.
                 *
                 * floor = 408279424  (~408 MHz, observed in seninf logs)
                 * vb_min = ceil(floor / ((width+hblank) * fps_Hz)) - height
                 */
                if (cam->state.framerate > 0 && hblank.min > 0)
                {
                        u32 fps_hz_x1000 = cam->state.framerate; /* milli-fps */
                        /* Use the active (crop) width — seninf computes its frame monitor
                         * period as (crop_w + hblank) × (crop_h + vblank) × fps.
                         * Using cam->ctrl.frame.width (full-sensor width) here gives a
                         * row_pixels that is ~2× too large, making needed_total too small
                         * and suppressing the floor padding when cropped. */
                        u32 active_width = cam->state.frame.width > 0
                                               ? cam->state.frame.width
                                               : cam->ctrl.frame.width;
                        u32 row_pixels = active_width + hblank.min;
                        /* needed_total = ceil(408279424 * 1000 / (row_pixels * fps_hz_x1000)) */
                        u32 needed_total = (u32)div_u64(
                            408279424ULL * 1000 + (u64)row_pixels * fps_hz_x1000 - 1,
                            (u64)row_pixels * fps_hz_x1000);
                        if (needed_total > height + vblank.def)
                                vblank.def = needed_total - height;
                }
        }

        /* hblank in output-pixel units (what seninf expects for V4L2_CID_HBLANK).
         * HMAX is in sensor internal-clock cycles (clk_pixel domain);
         * pixel_rate is the output pixel rate at the CSI-2 receiver.
         * Conversion: hmax_output = HMAX * pixel_rate / clk_pixel
         * Then: hblank = hmax_output - active_width.
         * Example – IMX900 mode 7 (4-lane 10bit):
         *   HMAX=364, pixel_rate=594 MHz, clk_pixel=74.25 MHz
         *   hmax_output = 364 * 8 = 2912, hblank = 2912 - 2048 = 864 */
        if (clk_pixel > 0)
        {
                /* Use the active (crop) width, not the full sensor width — a
                 * cropped mode's output width is narrower than hmax_*_out,
                 * so using the full sensor width here underestimates hblank
                 * and libcamera derives too small a line time from it. */
                u32 active_width = cam->state.frame.width > 0
                                       ? cam->state.frame.width
                                       : cam->ctrl.frame.width;
                u32 hmax_min_out = (u32)div_u64((u64)mode->hmax.min * pixel_rate.max,
                                                clk_pixel);
                u32 hmax_max_out = (u32)div_u64((u64)mode->hmax.max * pixel_rate.max,
                                                clk_pixel);
                u32 hmax_def_out = (u32)div_u64((u64)mode->hmax.def * pixel_rate.max,
                                                clk_pixel);
                hblank.min = (hmax_min_out > active_width)
                                 ? hmax_min_out - active_width
                                 : 0;
                hblank.max = (hmax_max_out > active_width)
                                 ? hmax_max_out - active_width
                                 : 0;
                hblank.def = (hmax_def_out > active_width)
                                 ? hmax_def_out - active_width
                                 : 0;
        }
        else
        {
                hblank.min = 0;
                hblank.max = 0;
                hblank.def = 0;
        }
        /* Keep config structs in sync so ctrl_hblank/ctrl_vblank hold the correct
         * values at init time (vc_update_clk_rates is called before ctrl creation).
         * Mark hblank read-only when the sensor does not allow hmax manipulation. */
        ctrl_hblank.min = hblank.min;
        ctrl_hblank.max = hblank.max;
        ctrl_hblank.def = hblank.def;
        if (mode->hmax.min == mode->hmax.max)
                ctrl_hblank.flags |= V4L2_CTRL_FLAG_READ_ONLY;
        else
                ctrl_hblank.flags &= ~V4L2_CTRL_FLAG_READ_ONLY;
        ctrl_vblank.min = vblank.min;
        ctrl_vblank.max = vblank.max;
        ctrl_vblank.def = vblank.def;

        /* Reflect updated hblank into the live V4L2 control so seninf's
         * get_buffered_pixel_rate() reads the correct value instantly.
         * Use the cached pointer — never call v4l2_ctrl_find() here because
         * this function runs inside s_ctrl which already holds
         * ctrl_handler->lock, and v4l2_ctrl_find() would try to acquire
         * the same lock → deadlock. */
        if (device->hblank_ctrl)
        {
                device->hblank_ctrl->minimum = hblank.min;
                device->hblank_ctrl->maximum = hblank.max;
                device->hblank_ctrl->default_value = hblank.def;
                device->hblank_ctrl->val = hblank.def;
                device->hblank_ctrl->cur.val = hblank.def;
                /* Also propagate the read-only flag so a writable hmax range
                 * (MODE_HMAX) is correctly exposed after the first set_fmt. */
                if (mode->hmax.min == mode->hmax.max)
                        device->hblank_ctrl->flags |= V4L2_CTRL_FLAG_READ_ONLY;
                else
                        device->hblank_ctrl->flags &= ~V4L2_CTRL_FLAG_READ_ONLY;
        }

       

        /* Update live V4L2_CID_VBLANK control with the actual vblank. */
        if (device->vblank_ctrl)
        {
                device->vblank_ctrl->minimum = vblank.min;
                device->vblank_ctrl->maximum = vblank.max;
                device->vblank_ctrl->default_value = vblank.def;
                device->vblank_ctrl->val = vblank.def;
                device->vblank_ctrl->cur.val = vblank.def;
        }


        if (device->pixel_rate_ctrl)
        {
                device->pixel_rate_ctrl->minimum = pixel_rate.min;
                device->pixel_rate_ctrl->maximum = pixel_rate.max;
                device->pixel_rate_ctrl->default_value = pixel_rate.def;
                if (device->pixel_rate_ctrl->p_cur.p_s64)
                        *device->pixel_rate_ctrl->p_cur.p_s64 = pixel_rate.def;
        }
}

static void vc_update_blacklevel_ctrl(struct vc_device *device, struct vc_cam *cam)
{
        /* Reflect the current mode's black level default into the live V4L2 control.
         * cam->state.blacklevel is the relative value (0..100000) computed by
         * vc_core from the mode's blacklevel.def/max. */
        ctrl_blacklevel.def = cam->state.blacklevel;
        if (device->blacklevel_ctrl)
        {
                device->blacklevel_ctrl->default_value = cam->state.blacklevel;
                device->blacklevel_ctrl->val = cam->state.blacklevel;
                device->blacklevel_ctrl->cur.val = cam->state.blacklevel;
        }
}

static void update_frame_rate_ctrl(struct vc_cam *cam, struct vc_device *device)
{
        struct v4l2_ctrl *ctrl = v4l2_ctrl_find(&device->ctrl_handler, V4L2_CID_VC_FRAME_RATE);
        if (ctrl)
        {
                ctrl->maximum = cam->ctrl.framerate.max;
                ctrl->minimum = cam->ctrl.framerate.min;
                ctrl->default_value = cam->ctrl.framerate.def;
                ctrl->val = cam->state.framerate;
        }
}
int vc_sd_update_fmt(struct vc_device *device)
{
        __u8 h_scale, v_scale;
        vc_get_binning_scale(&device->cam, &h_scale, &v_scale);
        struct v4l2_subdev_format fmt = {
            .which = V4L2_SUBDEV_FORMAT_ACTIVE,
            .format = {
                .code = device->cam.state.format_code,
                .width = device->cam.ctrl.frame.width / h_scale,
                .height = device->cam.ctrl.frame.height / v_scale,
                .field = V4L2_FIELD_NONE,
                .colorspace = V4L2_COLORSPACE_SRGB,
            },
        };

        return v4l2_subdev_call(&device->sd, pad, set_fmt, NULL, &fmt);
}
static int vc_sd_init(struct vc_device *device)
{
        struct i2c_client *client = device->cam.ctrl.client_sen;
        struct device *dev = &client->dev;
        int ret;

        // Initializes the subdevice
        v4l2_i2c_subdev_init(&device->sd, client, &vc_subdev_ops);

        // Initialize the handler
        ret = v4l2_ctrl_handler_init(&device->ctrl_handler, 3);
        if (ret)
        {
                vc_err(dev, "%s(): Failed to init control handler\n", __func__);
                return ret;
        }
        // Hook the control handler into the driver
        device->sd.ctrl_handler = &device->ctrl_handler;

        vc_update_clk_rates(device, &device->cam);
        vc_update_blacklevel_ctrl(device, &device->cam);
        struct v4l2_ctrl *ctrl;

        if (device->libcamera_enabled)
        {
                device->cam.ctrl.exposure.min = 1;
                device->cam.ctrl.exposure.max = 1000000;
                device->cam.ctrl.exposure.def = 10;
        }

        // Add controls
        ret |= vc_ctrl_init_ctrl(device, &device->ctrl_handler, V4L2_CID_EXPOSURE, &device->cam.ctrl.exposure, 0, NULL);
        ret |= vc_ctrl_init_ctrl_special(device, &device->ctrl_handler, V4L2_CID_ANALOGUE_GAIN,
                                         0, device->cam.ctrl.again.max_mdB + device->cam.ctrl.dgain.max_mdB, 0);
        device->gain_ctrl = v4l2_ctrl_find(&device->ctrl_handler, V4L2_CID_ANALOGUE_GAIN);

        ret |= vc_ctrl_init_custom_ctrl(device, &device->ctrl_handler, &ctrl_blacklevel, &device->blacklevel_ctrl);
        ret |= vc_ctrl_init_custom_ctrl(device, &device->ctrl_handler, &ctrl_orientation, &ctrl);

        struct v4l2_ctrl_config trigger_mode_cfg = ctrl_trigger_mode;
        trigger_mode_cfg.menu_skip_mask = vc_trigger_mode_skip_mask(device->cam.ctrl.flags);
        ret |= vc_ctrl_init_custom_ctrl(device, &device->ctrl_handler, &trigger_mode_cfg, &ctrl);
        ret |= vc_ctrl_init_custom_ctrl(device, &device->ctrl_handler, &ctrl_rotation, &ctrl);

        struct v4l2_ctrl_config io_mode_cfg = ctrl_flash_mode;
        io_mode_cfg.menu_skip_mask = vc_io_mode_skip_mask(device->cam.ctrl.flags);
        ret |= vc_ctrl_init_custom_ctrl(device, &device->ctrl_handler, &io_mode_cfg, &ctrl);
        ret |= vc_ctrl_init_custom_ctrl(device, &device->ctrl_handler, &ctrl_frame_rate, &ctrl);
        ret |= vc_ctrl_init_custom_ctrl(device, &device->ctrl_handler, &ctrl_single_trigger, &ctrl);
        ret |= vc_ctrl_init_custom_ctrl(device, &device->ctrl_handler, &ctrl_binning_mode, &ctrl);
        ret |= vc_ctrl_init_custom_ctrl(device, &device->ctrl_handler, &ctrl_live_roi, &ctrl);
        ret |= vc_ctrl_init_custom_ctrl(device, &device->ctrl_handler, &ctrl_name, &ctrl);

        ret |= vc_ctrl_init_ctrl(device, &device->ctrl_handler, V4L2_CID_PIXEL_RATE, &pixel_rate, 0, &device->pixel_rate_ctrl);
        ret |= vc_ctrl_init_ctrl_lfreq(device, &device->ctrl_handler, V4L2_CID_LINK_FREQ, &linkfreq);
        ret |= vc_ctrl_init_custom_ctrl(device, &device->ctrl_handler, &ctrl_hblank, &device->hblank_ctrl);
        ret |= vc_ctrl_init_custom_ctrl(device, &device->ctrl_handler, &ctrl_vblank, &device->vblank_ctrl);
        ret |= vc_ctrl_init_ctrl_lc(device, &device->ctrl_handler);
        
        if (ret)
        {
                vc_err(dev, "%s(): Failed to set format\n", __func__);
                return ret;
        }

        vc_sd_update_fmt(device);

        return 0;
}

static int vc_link_setup(struct media_entity *entity, const struct media_pad *local, const struct media_pad *remote,
                         __u32 flags)
{
        return 0;
}

static const struct media_entity_operations vc_sd_media_ops = {
    .link_setup = vc_link_setup,
};

static int vc_probe(struct i2c_client *client)
{
        struct device *dev = &client->dev;
        struct vc_device *device;
        struct vc_cam *cam;
        int ret;

        vc_notice(dev, "%s(): Probing UNIVERSAL VC MIPI Driver (v%s)\n", __func__, VERSION);

        device = devm_kzalloc(dev, sizeof(*device), GFP_KERNEL);
        if (!device)
                return -ENOMEM;

        cam = &device->cam;
        cam->ctrl.client_sen = client;

        mutex_init(&device->mutex);

        vc_set_power(device, 1);

        ret = vc_core_init(cam, client);
        if (ret)
                goto error_release_core;

        ret = vc_check_hwcfg(cam, dev, device);

        if (ret)
                goto error_release_core;

        cam->force_color_mode = device->force_color_mode;
        if (cam->force_color_mode)
        {
                // vc_core_init already ran vc_core_update_mbus_codes with the real
                // sensor color flag. Rebuild now with the forced value.
                memset(cam->ctrl.mbus_codes, 0, sizeof(cam->ctrl.mbus_codes));
                vc_core_update_mbus_codes(cam);
        }

        vc_init_supported_mbus_codes(device);
        /* Defer module mode selection to stream start so sensor initialization
         * happens in the streaming path (vc_sen_start_stream). Overlays used to
         * dictate module mode at probe time in older drivers; on newer platforms
         * we initialize the module when streaming starts to pick the correct
         * mode based on runtime endpoint/format information. */
        ret = vc_sd_init(device);
        if (ret)
                goto error_handler_free;

        device->sd.flags |= V4L2_SUBDEV_FL_HAS_DEVNODE | V4L2_SUBDEV_FL_HAS_EVENTS;
        device->pad.flags = MEDIA_PAD_FL_SOURCE;
        device->sd.entity.ops = &vc_sd_media_ops;
        device->sd.entity.function = MEDIA_ENT_F_CAM_SENSOR;
        ret = media_entity_pads_init(&device->sd.entity, 1, &device->pad);
        if (ret)
                goto error_handler_free;

        ret = v4l2_subdev_init_finalize(&device->sd);
        if (ret)
                goto error_media_entity;

        ret = v4l2_async_register_subdev_sensor(&device->sd);
        if (ret)
                goto error_subdev_cleanup;

        /* Enable runtime PM and take one usage reference */
        pm_runtime_enable(dev);
        vc_notice(dev, "%s(): Runtime PM enabled\n", __func__);
        ret = pm_runtime_get_sync(dev);
        if (ret < 0)
        {
                vc_err(dev, "%s(): pm_runtime_get_sync failed: %d\n", __func__, ret);
                goto error_pm_disable;
        }
        vc_notice(dev, "%s(): Probe successful\n", __func__);
        return 0;

error_subdev_cleanup:
        v4l2_subdev_cleanup(&device->sd);
error_media_entity:
        media_entity_cleanup(&device->sd.entity);
error_handler_free:
        v4l2_ctrl_handler_free(&device->ctrl_handler);
        mutex_destroy(&device->mutex);
error_release_core:
        vc_set_power(device, 0);
        vc_core_release(cam);
        return ret;
error_pm_disable:
        pm_runtime_disable(dev);
        pm_runtime_set_suspended(dev);
        vc_set_power(device, 0);
        vc_core_release(cam);
        return ret;
}

static void vc_remove(struct i2c_client *client)
{
        struct v4l2_subdev *sd = i2c_get_clientdata(client);
        struct vc_device *device = to_vc_device(sd);

        v4l2_async_unregister_subdev(&device->sd);
        v4l2_subdev_cleanup(&device->sd);
        media_entity_cleanup(&device->sd.entity);
        v4l2_ctrl_handler_free(&device->ctrl_handler);
        mutex_destroy(&device->mutex);

        /* Release probe reference before disabling runtime PM */
        pm_runtime_put_sync(&client->dev);
        pm_runtime_disable(&client->dev);
        pm_runtime_set_suspended(&client->dev);
        vc_set_power(device, 0);
        vc_core_release(&device->cam);

        return;
}

static const struct dev_pm_ops vc_pm_ops = {
    SET_SYSTEM_SLEEP_PM_OPS(vc_suspend, vc_resume)};

static const struct i2c_device_id vc_id[] = {
    {"vc_mipi_camera", 0},
    {/* sentinel */},
};
MODULE_DEVICE_TABLE(i2c, vc_id);

static const struct of_device_id vc_dt_ids[] = {
    {.compatible = "vc,vc_mipi_modules"},
    {/* sentinel */}};
MODULE_DEVICE_TABLE(of, vc_dt_ids);

static struct i2c_driver vc_i2c_driver = {
    .driver = {
        .name = "vc_mipi_camera",
        .pm = &vc_pm_ops,
        .of_match_table = vc_dt_ids,
    },
    .id_table = vc_id,
    .probe = vc_probe,
    .remove = vc_remove,
};

module_i2c_driver(vc_i2c_driver);

MODULE_VERSION(VERSION_CAMERA);
MODULE_DESCRIPTION("Vision Components GmbH - VC MIPI CSI-2 driver");
MODULE_AUTHOR("Florian Schmid, Vision Components GmbH <florian.schmid@vision-components.com>");
MODULE_AUTHOR("Peter Martienssen, Liquify Consulting <peter.martienssen@liquify-consulting.de>");
MODULE_AUTHOR("Michael Steinel, Vision Components GmbH <mipi-tech@vision-components.com>");
MODULE_LICENSE("GPL v2");

module_param(debug, int, 0644);
MODULE_PARM_DESC(debug, "Debug level (0-6)");